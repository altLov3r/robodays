# Pololu 3pi+ Standard line follower

**R30 — lap 3 earns a local attack budget from lap 2.** For the stock **Pololu
3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on a white floor. Two
source files, no new libraries. Earlier releases remain archived.

## What changed

- **Lap 1:** the same slow map learning.
- **Lap 2:** R29's speed envelope, while recording local tracking quality in a
  128-byte packed map. A region needs two valid observations with absolute
  line error at most 160 and filtered derivative at most 40, without a crossing.
- **Lap 3:** a mapped bin can use the larger corner budget only if it and both
  neighbours were qualified on lap 2, with trusted gyro geometry and no noisy
  fallback. The curvature-derived squared-speed allowance rises **12.5%**;
  wheel ceilings, steering headroom, braking lookahead and live line caps still
  constrain it. This is about a 6% PWM-target rise when the curvature bound wins.
- **Local revocation:** a new out-of-margin observation rejects its bin and both
  neighbours. It cannot requalify itself on lap 3. Other clean regions keep their
  eligibility; no session-wide speed downgrade is added. The ordinary actuator
  ramp remains, so revoking a budget is not an instantaneous physical slowdown.
- **Planning correctness:** equal curvature with different qualification must
  be evaluated again. The planner still anticipates an unqualified section after
  a faster qualified section, including partial bins and map wrap.
- **Results:** a `+` after the limiter means a qualified corner budget was
  enabled during lap 3. It may have been a lookahead candidate; another limit
  can still dominate. It does not establish a motor-speed or lap-time gain.

R29's full-corner hold, 40 ms straight-launch confirmation, 1500 PWM/s maximum
launch, 250 PWM/s planned braking, 300 PWM/s normal output braking, entry guard,
400 motor ceiling and all fault stops remain. Safe/Mid and noisy-learning
fallback do not gain an attack budget. OLED writes remain off during motion.

In the fixed-input bend test, R29/lap-2 requests 243 PWM; a fully qualified lap-3
region requests and reaches 258. Unknown, rejected or isolated clean bins keep
the baseline. These are software checks, not a physical lap prediction.

**A clean previous lap is not a tyre-grip measurement.** The extra budget is
experimental and can still cause a departure. No code-only test can guarantee
a faster physical lap, a 2.7-second result, hardware protection or a competition
win. Compare complete sessions at similar battery charge and report laps 2/3,
completion count, `LIMIT` (including any `+`), PWM and `A/L/S` shares.

## Install and upload

1. Extract `releases/PololuLineFollower-R30.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R30**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe → Mid → Beast → Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and the new A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and projected error. The nominal lateral budgets are 1200/2400/6000 mm/s² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Qualified lap-3 Beast regions can add 12.5% to their
squared-speed budget (about 6% to a curvature-limited PWM target). Wheel ceilings and differential steering room also constrain
speed. No reverse wheel commands are used during line following.

Planned braking is 250 PWM/s, or 200 for noisy-learning fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |
| `LIMIT: M+` | A qualified lap-3 corner budget was enabled at least once; another bound may still have capped the final command. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

New R30 checks cover packed quality storage, two-sample qualification, dirty
neighbour rejection/wrap, mode/fault isolation, lap-3 learning exclusion, reset,
local revocation, live/map budget limits, dense-distance planning with mixed
quality, and repeated curvature with a changing qualification. The latter must
still brake for a future unqualified section. A fixed-input real-sketch check
raises common motor commands from 243 to 258 in the qualified final-lap fixture;
a new error revokes the extra budget, retains the normal braking ramp and does
not downgrade the whole lap. The result marker is checked both on and off.

The baseline planner still passes the existing R29 late-entry checks: three
bins of map delay with a 20 ms lead in the fixture, or two bins with 40 ms.
These are software requests, not measured physical stopping margins. Steering,
braking assumptions and entry guards remain unchanged from R29.

The optional historical trajectory models are retained in the tests but were
**not run for R30**. They do not characterize the physical robot.

The actual OLED/Leonardo build passes with warnings enabled:
**28,308/28,672 bytes flash; 1,620/2,560 bytes static RAM**. This leaves 364 bytes
of flash and 940 bytes for stack/local allocation, not a measured free-stack
minimum. The linked ELF contains no malloc/realloc/free allocator symbols.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R30 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
