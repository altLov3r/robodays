# Pololu 3pi+ Standard line follower

**R38 - earlier braking and more corner margin.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
white floor. Replace both sketch files together. Earlier release ZIPs remain.

## What changed

The robot still departed corners with R37. This revision removes the R36
corner-pace increase and gives entry braking more distance:

- Qualified Beast's nominal lateral budget returns from 6300 to **6000 mm/s2**.
  At the user's reported scale 820/width 84 and curvature 30, the corner request
  returns from **311 to 303 PWM**. This is a requested speed, not measured grip.
- Qualified Beast plans braking at **250 instead of approximately 280 PWM/s**.
  The actual routine braking ramp remains 300 PWM/s. The planner therefore
  starts reducing the target earlier, rather than adding harsher output braking.
- The entry guard grows by **64 encoder counts (about 18 mm)**, to approximately
  **106 mm + 60 ms of travel**. Future bends keep this margin even when a
  trailing corner bin releases. Late-map tests cover both turn directions.

The corner budget/braking rate match the earlier R34/R35 settings, with more
entry distance. R37's 2400 PWM/s qualified straight boost, 400 PWM ceiling,
continuous alignment gate, actual output-restoration ramp, delivered-base turn
assistance and straight derivative scheduling remain. Safe/Mid and fallback
profiles retain their existing values. No new Arduino dependencies.

## Validation and limits

- Native regressions pass. Dense-distance checks verify the restored 250 PWM/s
  envelope and the extra entry margin across scale, geometry, mode and direction.
  Requested speeds never exceed the prior R35 planner for matching inputs.
- Settled 200->300 PWM command recovery remains **45 ms**. The exit-surge fixture
  remains **280->283 PWM per 5 ms**, rather than restoring hidden throttle at once.
- Paired R37/R38 tests at 5 ms and 10 ms replay each contain 22 motion cases plus
  command/release fixtures. Both versions complete all cases. Straight-only
  outcomes are unchanged. Most square laps are slower; tracking-offset changes
  are mixed. These results do not establish physical completion reliability.
- Leonardo build: **28,498/28,672 bytes flash**, **1506/2560 static RAM**.
  No linked heap allocators. Remaining stack/local space is 1054 bytes;
  peak stack, loop latency, tire friction, battery sag and pitching are unmeasured.

This version deliberately sacrifices some corner pace to address departures.
First verify Safe, then test Beast at similar charge/placement. Note whether any
remaining loss occurs on entry, mid-corner or exit, and on which lap. Keep the
previous ZIP for comparison. Physical testing is needed to tune further.

## Install and upload

1. Extract `releases/PololuLineFollower-R38.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R38**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe â†’ Mid â†’ Beast â†’ Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and filtered error derivative. The nominal lateral budgets are 1200/2400/6000 mm/sÂ² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Both replay laps use the same budget. Wheel ceilings and
differential steering room also constrain speed. No reverse wheel commands are used during line following.

Planned braking is 250 PWM/s for normal profiles, or 200 for noisy-learning
fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration or throttle restoration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

R38 checks the restored corner budget and 250 PWM/s envelope, earlier corner
requests, late maps and unchanged fallback profiles. The corner-exit regressions
retain qualification, rebound, throttle-restoration and steering-gain checks.

Run paired models separately:

```powershell
python tests/compare_motion.py --baseline R37 --stress --output releases/PololuLineFollower-R38-motion.json
python tests/compare_motion.py --baseline R37 --stress --period-ms 10 --output releases/PololuLineFollower-R38-motion-10ms.json
```

The same current harness compiles against frozen R37 and current firmware.
The full historical trajectory suite was not run. Both comparison reports are
included in the R38 ZIP. Models are uncalibrated and have no measured tire grip.

Warnings-enabled OLED/Leonardo builds use **28,498/28,672 bytes flash** and
**1506/2560 bytes static RAM**, with no malloc/calloc/realloc/free symbols linked.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R38 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
