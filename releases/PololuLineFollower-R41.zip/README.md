# Pololu 3pi+ Standard line follower

**R41 - earlier Beast braking and a small corner-speed reserve.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
white floor. Replace both sketch files together. R40 remains available.

## What changed

- Beast's healthy, trusted replay planner adds **one map bin (about 36 mm)**
  to its pre-corner distance reserve: about **142 mm + 60 ms of travel**.
  It requests corner pace earlier; the normal 300 PWM/s output braking ramp
  remains unchanged. This does not add a harsher brake command.
- The same planner's lateral budget changes **6000->5600 mm/s^2**. This lowers
  lateral-limited corner PWM by roughly **3-4%**. Wheel/steering caps can limit
  corners independently, so the reduction is not uniform on every bend.
- Straight cruise and qualified acceleration remain **400 PWM / 2400 PWM/s**.
  Braking sooner can reduce average straight speed when another corner is near.
  The map/steering algorithm, 35 ms optical qualification and yaw gates remain.
- R40's completed-session reference remains in RAM until power-off/reset.
  Each B still relearns the map and gyro bias. A lower raw learning scale is
  bounded by the highest clean Beast completion for its model conversions.
- **No line still stops immediately.** Its threshold and other fault stops
  remain unchanged. This is corner-margin tuning after R40 failed physically;
  it does not establish whether the loss occurred at entry, apex or exit.

## Validation and limits

- Focused native checks pass, including dense-distance planning, entry/wrap
  bounds, both directions, lower bend targets, mode isolation, seven repeated
  starts, reference retention, output ramps and the immediate line-loss stop.
- At the reported example scale/width **820/84**, curvature 30, the corner
  target decreases **303->293 PWM**. At 1000 mm/s and 202 mm before the mapped
  bend, it decreases **312->293 PWM**. An open straight still requests 400.
- Paired R40/R41 reports at 5 ms and 10 ms each contain 22 motion cases plus
  seven control/diagnostic fixtures. All current cases pass. Warm launch stays
  45 ms, pending-straight launch stays 65 ms and hidden release stays 280->283.
  The new earlier-entry fixture deliberately fails R40's target criterion.
- Most rounded-square model laps are slower by roughly 0.1-0.16 seconds; offset
  results are mixed. This is a consistency-oriented candidate, not a proven
  physical speed or completion improvement. Models have no calibrated tire grip.
- Leonardo build: **28,570/28,672 bytes flash**, **1508/2560 static RAM**.
  No linked heap allocators. The 1052 bytes left for stack/locals are not a
  measured stack margin. Grip, motor temperature and battery sag are unmeasured.

Recalibrate and test several Beast sessions. Record successful lap times and,
if it stops, the displayed error/derivative pair and whether it left the line
at corner entry, middle or exit. Keep R40 for comparison. Physical stability
and sub-three-second times remain unverified.

## Install and upload

1. Extract `releases/PololuLineFollower-R41.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R41**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe â†’ Mid â†’ Beast â†’ Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session; R41 retains its completed-session
  reference until power-off. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and filtered error derivative. The nominal lateral budgets are 1200/2400/6000 mm/sÂ² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Both replay laps use the same budget. Wheel ceilings and
differential steering room also constrain speed. No reverse wheel commands are used during line following.

Planned braking is 250 PWM/s for normal profiles, or 200 for noisy-learning
fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration or throttle restoration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

Earlier planner, mismatch-window, launch, mode, fault, line-loss, calibration
and repeated-start checks remain. Current planner assertions use independent
dense-distance evaluation with R41's intended corner budget and entry distance.
Historical faster-than-R28 bounds are replaced by no-faster-than-R40 bounds;
the earlier-entry fixture requires reaching the lower corner target sooner.

Run paired models separately:

```powershell
python tests/compare_motion.py --baseline R40 --stress --output releases/PololuLineFollower-R41-motion.json
python tests/compare_motion.py --baseline R40 --stress --period-ms 10 --output releases/PololuLineFollower-R41-motion-10ms.json
```

The same current harness compiles against frozen R40 and current firmware.
The new earlier-entry fixture intentionally exposes the prior target difference;
current firmware must meet the new reserve while retaining the straight target.
The full historical trajectory suite was not run. Both reports are included
in the R41 ZIP. Models do not calibrate physical tire grip or battery sag.

Warnings-enabled OLED/Leonardo builds use **28,570/28,672 bytes flash** and
**1508/2560 bytes static RAM**, without linked malloc/calloc/realloc/free.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R41 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
