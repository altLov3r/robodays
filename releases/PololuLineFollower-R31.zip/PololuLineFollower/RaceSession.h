#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

constexpr uint8_t RACE_PLANNER_REVISION = 31;

enum DriveMode : uint8_t { SAFE, MID, BEAST };

struct DriveProfile
{
  int16_t cruise;
  int16_t limit;
};

inline DriveProfile driveProfile(DriveMode mode, bool learning)
{
  if (learning) { return {80, 100}; }
  if (mode == MID) { return {180, 220}; }
  if (mode == BEAST) { return {400, 400}; }
  return {120, 140};
}

// Distance-indexed signed curvature, without an absolute position reference.
// Loop closure is an estimate: wheel slip/gyro drift can prevent or fool it.
class RaceSession
{
public:
  static constexpr uint16_t BIN_COUNTS = 128;
  static constexpr uint16_t MAP_CAPACITY = 512;
  static_assert(static_cast<uint32_t>(BIN_COUNTS) * MAP_CAPACITY <= 65536UL,
    "Map positions must fit in 16 bits.");
  static constexpr uint32_t LAP_TIMEOUT_MS = 90000;
  static constexpr float MM_PER_COUNT = 32.0f * 3.14159265f / 358.3f;
  static constexpr int8_t UNKNOWN_CURVE = -128;
  enum Fault : uint8_t { NONE, MAP_FULL, MAP_GAP, MAP_MISMATCH, NO_FINISH, BAD_MOTION };
  enum Event : uint8_t { NO_EVENT, LAP_FINISHED, SESSION_FINISHED };

  DriveMode mode = SAFE;
  Fault fault = NONE;
  bool running = false;
  bool mapReady = false;
  uint8_t completed = 0;
  uint32_t lapTimes[3] = {};
  uint32_t learnedCounts = 0;
  uint16_t binsUsed = 0;
  int8_t curves[MAP_CAPACITY]; // Signed curvature * 6000: radius 75 mm is +/-80.
  uint8_t replayQuality[(MAP_CAPACITY + 3) / 4] = {}; // Two bits: unseen/once/clean/rejected.
  mutable bool attackUsed = false; // Budget was enabled; another speed cap may still dominate.
  uint32_t distanceTwice = 0;
  uint32_t lapStarted = 0;
  float x = 0, y = 0, heading = 0, speedMmS = 0;
  bool leftStartZone = false;
  bool returnArmed = false;
  uint16_t mismatchMs = 0;
  int16_t filteredCurve = 0; // Curvature in eighths to retain filter precision.
  uint16_t speedScaleQ8 = 1024; // Measured mm/s per PWM, initially 4.0.
  uint8_t trackWidthMm = 86;
  int8_t turnVotes = 0;
  int16_t learningDifference = 0;
  float learningTurn = 0;
  uint8_t learningSamples = 0;
  int32_t mapCurveSum = 0;
  uint16_t mapWeight = 0;
  uint8_t learningNoise = 0;
  bool noisyLearning = false;
  mutable bool liveLimited = false; // Telemetry only; never changes the speed bound.
  mutable uint8_t launchCurveLimit = 0; // Q3 yaw limit; zero disables strong launches.
  uint8_t exitQuietMs = 0;

  void reset(DriveMode selected, uint32_t now)
  {
    mode = selected;
    fault = NONE;
    running = true;
    mapReady = false;
    completed = 0;
    learnedCounts = 0;
    binsUsed = 0;
    speedMmS = 0;
    filteredCurve = 0;
    speedScaleQ8 = 1024;
    trackWidthMm = 86;
    turnVotes = 0;
    learningDifference = 0;
    learningTurn = 0;
    learningSamples = 0;
    mapCurveSum = 0;
    mapWeight = 0;
    learningNoise = 0;
    noisyLearning = false;
    liveLimited = false;
    launchCurveLimit = 0;
    exitQuietMs = 0;
    memset(curves, 128, sizeof(curves));
    memset(replayQuality, 0, sizeof(replayQuality));
    attackUsed = false;
    memset(lapTimes, 0, sizeof(lapTimes));
    resetLap(now);
  }

  void abort()
  {
    running = false;
    if (completed < 3) { mapReady = false; }
  }

  DriveProfile profile() const { return driveProfile(noisyLearning ? MID : mode, !mapReady); }
  int16_t steeringLimit() const
  { return !mapReady ? 90 : (noisyLearning ? 110 : (mode == BEAST ? 140 : (mode == MID ? 110 : 90))); }
  uint32_t distanceCounts() const { return distanceTwice / 2; }
  __attribute__((noinline)) uint16_t mapPosition() const
  { return distanceCounts() % learnedCounts; }

  uint8_t qualityAt(uint16_t bin) const
  { return (replayQuality[bin / 4] >> (2 * (bin % 4))) & 3; }

  void setQuality(uint16_t bin, uint8_t value)
  {
    const uint8_t shift = 2 * (bin % 4);
    uint8_t & packed = replayQuality[bin / 4];
    packed = (packed & ~(3U << shift)) | (value << shift);
  }

  void noteReplayTracking(int16_t error, int16_t delta, bool crossing)
  {
    if (!running || fault != NONE || !mapReady || !learnedCounts || !binsUsed || mode != BEAST || noisyLearning ||
      abs(turnVotes) < 4 || (completed != 1 && completed != 2)) { return; }
    const uint16_t bin = mapPosition() / BIN_COUNTS;
    const bool clean = !crossing && abs(error) <= 160 && abs(delta) <= 40;
    if (!clean)
    {
      // Reject the neighbouring footprint too: sensors and map phase are offset.
      setQuality(bin, 3);
      setQuality(bin ? bin - 1 : binsUsed - 1, 3);
      setQuality(bin + 1 < binsUsed ? bin + 1 : 0, 3);
    }
    else if (completed == 1 && qualityAt(bin) < 2)
    { setQuality(bin, qualityAt(bin) + 1); }
  }

  bool attackEligible(uint16_t bin) const
  {
    if (!running || fault != NONE || !mapReady || !learnedCounts || !binsUsed || bin >= binsUsed ||
      completed != 2 || mode != BEAST || noisyLearning ||
      abs(turnVotes) < 4) { return false; }
    return qualityAt(bin) == 2 && qualityAt(bin ? bin - 1 : binsUsed - 1) == 2 &&
      qualityAt(bin + 1 < binsUsed ? bin + 1 : 0) == 2;
  }

  void noteTracking(int16_t, int16_t delta, bool)
  {
    if (!running || mapReady || mode != BEAST) { return; }
    // Reject isolated spikes. Sustained noise still selects the fallback before
    // replay; its motor ceiling must never change during a racing lap.
    if (abs(delta) >= 150)
    { if (learningNoise < 8) { learningNoise++; } }
    else if (learningNoise) { learningNoise--; }
    if (learningNoise == 8) { noisyLearning = true; }
  }

  void resetLap(uint32_t now)
  {
    distanceTwice = 0;
    lapStarted = now;
    x = y = heading = 0;
    leftStartZone = returnArmed = false;
    mismatchMs = 0;
  }

  Event update(int16_t left, int16_t right, float turnRadians,
    uint16_t elapsedMs, int16_t drivePwm, uint32_t now)
  {
    if (!running || fault != NONE || completed >= 3) { return NO_EVENT; }
    if (!elapsedMs || elapsedMs > 50 || left < -2 || right < -2 ||
      left > 500 || right > 500 || !isfinite(turnRadians) || fabsf(turnRadians) > 0.7f)
    {
      fault = BAD_MOTION;
      return NO_EVENT;
    }
    if (now - lapStarted >= LAP_TIMEOUT_MS)
    {
      fault = NO_FINISH;
      return NO_EVENT;
    }
    int16_t sum = left + right; // Validated wheel deltas bound this to -4..1000.
    if (sum < 0) { sum = 0; }
    distanceTwice += sum;
    const float step = sum * 0.5f * MM_PER_COUNT;
    // Encoder quantization must not make the braking horizon jump every sample.
    const float filterWeight = elapsedMs / (30.0f + elapsedMs);
    speedMmS += (step * 1000.0f / elapsedMs - speedMmS) * filterWeight;
    const float previousX = x;
    x += step * cosf(heading + turnRadians * 0.5f);
    y += step * sinf(heading + turnRadians * 0.5f);
    heading += turnRadians;
    if (heading > 3.14159265f) { heading -= 6.28318530f; }
    if (heading < -3.14159265f) { heading += 6.28318530f; }

    // Filter signed curvature: alternating steering jitter is not a sustained bend.
    float curve = sum > 0 ? turnRadians * 48000.0f / step : 0;
    if (curve > 1016) { curve = 1016; }
    if (curve < -1016) { curve = -1016; }
    const int16_t sampleCurve = static_cast<int16_t>(curve);
    const bool moving = sum >= 4; // At least 0.5 mm with the stock encoder scale.
    const int16_t liveCurve = moving ? sampleCurve : 0;
    if (mapReady && moving && abs(liveCurve) < 32)
    {
      if (exitQuietMs < 40) { exitQuietMs += elapsedMs; }
    }
    else { exitQuietMs = 0; }
    filteredCurve += static_cast<int32_t>(liveCurve - filteredCurve) *
      elapsedMs / (30 + elapsedMs);
    const int8_t bend = filteredCurve / 8;
    const uint8_t magnitude = abs(bend);
    const uint32_t distance = distanceCounts();
    if (!mapReady)
    {
      // Estimate the stock drivetrain's speed scale on settled learning straights.
      if (magnitude <= 3 && drivePwm >= 80 && speedMmS > 100)
      {
        const uint16_t sample = static_cast<uint32_t>(speedMmS) * 256 / drivePwm;
        if (sample >= 256 && sample <= 1536)
        { speedScaleQ8 = (speedScaleQ8 * 7 + sample) / 8; }
      }
      // Learn yaw polarity and effective wheel spacing from encoder/gyro agreement.
      // Do not assume the simulator's axis convention or exact tyre geometry.
      // Integrate paired measurements: slow/broad turns are below the per-tick
      // angle threshold, and single encoder counts otherwise bias the width.
      if (magnitude >= 8)
      {
        learningDifference += left - right;
        learningTurn += turnRadians;
        learningSamples++;
        if (fabsf(learningTurn) >= 0.04f || learningSamples >= 20)
        {
          if (fabsf(learningTurn) >= 0.04f)
          {
            const float width = learningDifference * MM_PER_COUNT / learningTurn;
            const float magnitudeWidth = fabsf(width);
            if (magnitudeWidth >= 59.5f && magnitudeWidth < 110.5f)
            {
              const uint16_t sample = static_cast<uint16_t>(magnitudeWidth + 0.5f);
              trackWidthMm = (trackWidthMm * 7 + sample + 4) / 8;
              if (width > 0 && turnVotes < 8) { turnVotes++; }
              if (width < 0 && turnVotes > -8) { turnVotes--; }
            }
          }
          learningDifference = 0;
          learningTurn = 0;
          learningSamples = 0;
        }
      }
      else
      {
        learningDifference = 0;
        learningTurn = 0;
        learningSamples = 0;
      }
      // Integrate signed turning by distance, splitting a sample at bin edges.
      // A single steering spike must not become a permanent corner speed cap.
      if (distance / BIN_COUNTS >= MAP_CAPACITY) { fault = MAP_FULL; return NO_EVENT; }
      uint32_t point = distanceTwice - sum;
      if (point / (BIN_COUNTS * 2UL) > binsUsed) { fault = MAP_GAP; return NO_EVENT; }
      uint16_t remaining = sum;
      while (remaining)
      {
        const uint16_t bin = point / (BIN_COUNTS * 2UL);
        if (bin == binsUsed) { mapCurveSum = 0; mapWeight = 0; }
        uint16_t span = BIN_COUNTS * 2 - point % (BIN_COUNTS * 2);
        if (span > remaining) { span = remaining; }
        mapCurveSum += static_cast<int32_t>(sampleCurve) * span;
        mapWeight += span;
        curves[bin] = mapCurveSum / mapWeight / 8;
        binsUsed = bin + 1;
        point += span;
        remaining -= span;
      }
    }
    else
    {
      if (distance > learnedCounts + learnedCounts * 15 / 100)
      {
        fault = NO_FINISH;
        return NO_EVENT;
      }
      const uint16_t bin = mapPosition() / BIN_COUNTS;
      uint8_t expected = abs(curves[bin]);
      const uint16_t previous = bin ? bin - 1 : binsUsed - 1;
      const uint16_t next = bin + 1 < binsUsed ? bin + 1 : 0;
      if (abs(curves[previous]) > expected) { expected = abs(curves[previous]); }
      if (abs(curves[next]) > expected) { expected = abs(curves[next]); }
      if (magnitude > expected + 16)
      {
        mismatchMs += elapsedMs;
        if (mismatchMs >= 200) { fault = MAP_MISMATCH; return NO_EVENT; }
      }
      else { mismatchMs = 0; }
    }

    if (x * x + y * y > 150.0f * 150.0f) { leftStartZone = true; }
    if (leftStartZone && x < -50 && x > -300 && fabsf(y) < 150 && fabsf(heading) < 0.6f)
    {
      returnArmed = true;
    }
    // Cross the starting plane forwards, near the initial position and heading.
    const bool closure = returnArmed && previousX < 0 && x >= 0 &&
      fabsf(y) <= 80 && fabsf(heading) <= 0.25f;
    if (closure && distance * MM_PER_COUNT < 750)
    {
      fault = NO_FINISH; // Do not silently combine multiple small loops into one lap.
      return NO_EVENT;
    }
    if (!closure || (mapReady && distance < learnedCounts * 85 / 100)) { return NO_EVENT; }
    if (!mapReady)
    {
      learnedCounts = distance;
      // A crossing exactly on a bin boundary must not retain a zero-length bin.
      binsUsed = (learnedCounts - 1) / BIN_COUNTS + 1;
      mapReady = true;
    }
    lapTimes[completed] = now - lapStarted;
    completed++;
    if (completed == 3)
    {
      running = false;
      return SESSION_FINISHED;
    }
    resetLap(now); // Anchor the next lap at the estimated crossing; do not accumulate pose error.
    return LAP_FINISHED;
  }

  // Share the live/map calculation to keep AVR flash use bounded.
  __attribute__((noinline)) uint32_t cornerSquared(uint8_t curvature, uint32_t lateralScale,
    bool attack = false) const
  {
    const DriveProfile active = profile();
    if (curvature <= 3) { return static_cast<uint32_t>(active.cruise) * active.cruise; }
    const uint16_t geometry = trackWidthMm * curvature;
    int16_t wheelCap = static_cast<uint32_t>(active.limit - 8) * 12000 / (12000 + geometry);
    const int16_t turnCap = static_cast<uint32_t>(steeringLimit() - 12) * 12000 / geometry;
    if (wheelCap > turnCap) { wheelCap = turnCap; }
    if (wheelCap > active.cruise) { wheelCap = active.cruise; }
    const uint32_t wheelSquared = static_cast<uint32_t>(wheelCap) * wheelCap;
    uint32_t allowed = lateralScale * 6000 / curvature;
    if (attack)
    {
      // Add 12.5% to the squared-speed budget, retaining every wheel/steering cap.
      const uint32_t boosted = allowed + allowed / 8;
      if (allowed < wheelSquared && boosted > 4225) { attackUsed = true; }
      allowed = boosted;
    }
    if (allowed > wheelSquared) { allowed = wheelSquared; }
    return allowed < 4225 ? 4225 : allowed;
  }

  __attribute__((noinline)) int16_t steeringFeedforward(int16_t base, int16_t error, uint8_t * yawWeight = nullptr) const
  {
    // Share map lookup: damping weight 0 disables it, 1 is half, 2 is full.
    if (yawWeight) { *yawWeight = 0; }
    if (!mapReady || !learnedCounts || abs(turnVotes) < 4) { return 0; }
    const uint16_t bin = mapPosition() / BIN_COUNTS;
    const bool mappedStraight = mapPhase(bin) & 1;
    const bool measuredAssistOnly = noisyLearning || (mode == BEAST && mappedStraight);
    if (yawWeight)
    {
      // Weaken damping before a bend, including the lap's partial final bin.
      *yawWeight = mappedStraight && abs(filteredCurve) < 64 ? 2 : 1;
    }
    int8_t mapped = curves[bin];
    int16_t live = filteredCurve / 8;
    int16_t confidence = abs(live) * 8;
    if (confidence < abs(error)) { confidence = abs(error); }
    if (abs(live) < 8)
    {
      // Optical lookahead sees corner entry before the chassis starts rotating.
      if (measuredAssistOnly || abs(error) < 60) { return 0; }
      live = (error > 0) == (turnVotes > 0) ? 8 : -8;
    }
    // A confirmed live bend may lead or trail the learned bin by a few cm.
    for (int8_t neighbor = -1; neighbor <= 1; neighbor++)
    {
      int16_t index = static_cast<int16_t>(bin) + neighbor;
      if (index < 0) { index = binsUsed - 1; }
      if (index >= static_cast<int16_t>(binsUsed)) { index = 0; }
      const int8_t candidate = curves[index];
      if (candidate != UNKNOWN_CURVE && static_cast<int16_t>(candidate) * live > 0 &&
        (mapped == UNKNOWN_CURVE || static_cast<int16_t>(mapped) * live <= 0 || abs(candidate) > abs(mapped)))
      { mapped = candidate; }
    }
    if (mapped == UNKNOWN_CURVE || static_cast<int16_t>(mapped) * live <= 0) { return 0; }
    int16_t bend = mapped;
    // Ramp the desired turn with measured entry confidence, without delaying
    // feedback or imposing a lagging slew limit on the wheel commands.
    if (!noisyLearning && confidence < 128)
    { bend = confidence <= 48 ? 0 : bend * (confidence - 48) / 80; }
    // Behind a bend, borrowed map curvature must not sustain more turn than
    // measured yaw. Entry and mapped bends retain their predictive assistance.
    if (measuredAssistOnly && abs(bend) > abs(live))
    { bend = live; }
    if (turnVotes < 0) { bend = -bend; }
    // Fade stale turn assistance continuously as the line asks to countersteer.
    // A binary veto caused assistance to switch on/off around corner exits.
    const int16_t opposing = bend > 0 ? -error : error;
    if (opposing >= 80) { return 0; }
    const int16_t assist = static_cast<int32_t>(base) * trackWidthMm * bend / 12000;
    return opposing > 0 ? static_cast<int32_t>(assist) * (80 - opposing) / 80 : assist;
  }

  __attribute__((noinline)) uint8_t mapPhase(uint16_t bin) const
  {
    const uint16_t next = bin + 1 < binsUsed ? bin + 1 : 0;
    return abs(curves[bin]) <= 3 && abs(curves[next]) <= 3 ? 1 : 0;
  }

  __attribute__((noinline)) int16_t plannedCruise() const
  {
    liveLimited = false;
    const DriveProfile active = profile();
    if (!mapReady || !learnedCounts || !binsUsed)
    { launchCurveLimit = 0; return active.cruise; }
    // Leave extra entry distance for spatial averaging and map phase error;
    // keep planned deceleration below the unchanged 300 PWM/s output ramp.
    const bool sprint = mode == BEAST && !noisyLearning && abs(turnVotes) >= 4;
    const uint16_t scale = speedScaleQ8 + speedScaleQ8 / 8;
    // Planned PWM/s: 200 for noisy learning, 250 otherwise; output remains 300.
    const uint16_t brakeGain = (noisyLearning ? 28672U : 35840U) / scale;
    const uint16_t lateral = mode == BEAST ?
      (noisyLearning ? 2400 : (abs(turnVotes) < 4 ? 3600 : 6000)) :
      (mode == MID ? 2400 : 1200);
    // Nested positive integer divisions by scale equal one division by scale^2.
    const uint32_t lateralScale = (static_cast<uint32_t>(lateral) * 65536) /
      (static_cast<uint32_t>(scale) * scale);
    uint16_t guard = 125 + static_cast<uint16_t>(speedMmS * 0.04f / MM_PER_COUNT);
    if (sprint)
    {
      // Keep half a bin more entry margin than R26, with its faster speed plan.
      guard += guard / 2 + 64 + BIN_COUNTS / 2;
    } // About 88 mm + 60 ms of travel.
    uint32_t targetSquared = static_cast<uint32_t>(active.cruise) * active.cruise;
    const uint16_t window = static_cast<uint16_t>((targetSquared - 4225) / brakeGain) + guard;
    uint16_t point = mapPosition();
    const uint32_t liveSquared = cornerSquared(abs(filteredCurve / 8), lateralScale,
      attackEligible(point / BIN_COUNTS));
    if (liveSquared < targetSquared) { targetSquared = liveSquared; liveLimited = true; }
    uint16_t offset = 0;
    uint8_t previousCurve = 0;
    bool previousAttack = false;
    // A quiet instant must not release a mapped bend before its final bin ends.
    const uint8_t phase = sprint ? mapPhase(point / BIN_COUNTS) : 0;
    // Fresh quiet yaw confirms the exit; allow more of the old filter tail.
    launchCurveLimit = (phase & 1) && exitQuietMs >= 40 ? 64 : 0;
    while (offset <= window)
    {
      const uint16_t bin = static_cast<uint16_t>(point / BIN_COUNTS);
      const uint16_t clear = offset > guard ? offset - guard : 0;
      const uint32_t braking = static_cast<uint32_t>(clear) * brakeGain;
      // Even the minimum corner target cannot constrain speed beyond this point.
      if (4225 + braking >= targetSquared) { break; }
      // Repeated curvature AND quality budget only loosen the bound farther ahead.
      // Revisit the same curvature when its qualification changes.
      const uint8_t curvature = abs(curves[bin]);
      const bool attack = curvature > 3 && attackEligible(bin);
      if (curvature > 3 && (curvature != previousCurve || attack != previousAttack))
      {
        previousCurve = curvature;
        previousAttack = attack;
        const uint32_t allowed = (curvature == 128 ? 4225 :
          cornerSquared(curvature, lateralScale, attack)) + braking;
        if (allowed < targetSquared) { targetSquared = allowed; liveLimited = false; }
      }
      // The last map bin can be partial: visit bin zero immediately after wrap.
      const uint16_t nextBin = BIN_COUNTS - point % BIN_COUNTS;
      const uint32_t toStart = learnedCounts - point;
      const uint16_t step = toStart < nextBin ? static_cast<uint16_t>(toStart) : nextBin;
      offset += step;
      point += step;
      if (point == learnedCounts) { point = 0; }
    }
    // Integer floor square root; the motor ceiling bounds the result to 400.
    uint16_t root = 0;
    for (uint16_t bit = 256; bit; bit >>= 1)
    {
      const uint16_t candidate = root | bit;
      if (static_cast<uint32_t>(candidate) * candidate <= targetSquared) { root = candidate; }
    }
    return root;
  }
};
