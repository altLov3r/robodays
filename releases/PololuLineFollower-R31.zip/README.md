# Pololu 3pi+ Standard line follower

**R31 — remove duplicate optical braking and improve clean corner recovery.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
a white floor. Two source files, no new libraries. Earlier releases stay archived.

## What changed

- **One optical envelope:** current error, derivative and the 20 ms projection
  produce a single cap from cruise. That cap competes with the mapped/live-yaw
  cap. The projection no longer multiplies an already-reduced corner request.
- **Stronger clean recovery:** trusted Beast replay can accelerate at up to
  **1000 PWM/s** in bends and before straight confirmation, up from 600.
  Current/projected error and derivative progressively reduce this to 600;
  risk at or above 240 receives no boost. Confirmed straights retain the
  existing maximum of **1500 PWM/s** and 40 ms quiet-yaw requirement.
- **Growing misses:** a projected absolute offset of 1000 or more requests the
  65 PWM floor. Routine reductions use the existing brake ramp; crossings,
  absolute error at least 700 or derivative at least 250 retain urgent braking.
- **R30's earned lap-3 budget stays:** a bin needs two clean lap-2 observations
  (absolute error at most 160, derivative at most 40, no crossing). It and both
  neighbours must qualify before lap 3 can add 12.5% to the curvature-derived
  squared-speed budget. Bad observations reject the bin and neighbours for
  the session; lap 3 cannot qualify itself. A result `+` means an eligible
  candidate budget was enabled, even if another cap dominated.

Map curvature budgets, full-corner hold, entry guard, 250 PWM/s planned braking,
300 PWM/s routine output braking, motor ceilings and fault stops stay in place.
Learning, Safe/Mid and noisy-learning fallback keep their prior speed logic.
The OLED remains blank during motion.

Fixed-input checks: the moderate growing-error bend fixture requests 243 PWM
instead of R30's 208. A clean bend recovers from 140 to 240 PWM in 100 ms instead
of 170 ms. These are controller commands, not measured vehicle acceleration or
lap-time predictions. The changed envelope needs a physical track test; no
code-only check can guarantee a faster lap or prevent a departure.

## Install and upload

1. Extract `releases/PololuLineFollower-R31.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R31**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe → Mid → Beast → Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and the new A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and projected error. The nominal lateral budgets are 1200/2400/6000 mm/s² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Qualified lap-3 Beast regions can add 12.5% to their
squared-speed budget (about 6% to a curvature-limited PWM target). Wheel ceilings and differential steering room also constrain
speed. No reverse wheel commands are used during line following.

Planned braking is 250 PWM/s, or 200 for noisy-learning fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |
| `LIMIT: M+` | A qualified lap-3 corner budget was enabled at least once; another bound may still have capped the final command. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

New R31 checks cover the combined optical cap, both turn directions, stronger
near-edge projection, urgent brake bypass, and isolation of learning/Safe/Mid/
noisy fallback. Actual-sketch fixed-input bend recovery is checked at 5/7/8/10/
20/40 ms periods, including exact target arrival without ramp overshoot. The
existing straight confirmation, corner hold, fractional braking, local lap-3
qualification/revocation, dense planner and stop regressions also pass.

The baseline planner still passes the existing R29 late-entry checks: three
bins of map delay with a 20 ms lead in the fixture, or two bins with 40 ms.
These are software requests, not measured physical stopping margins. Steering,
braking assumptions and entry guards remain unchanged from R29.

The optional historical trajectory models are retained in the tests but were
**not run for R31**. They do not characterize the physical robot.

The actual OLED/Leonardo build passes with warnings enabled:
**28,464/28,672 bytes flash; 1,620/2,560 bytes static RAM**. This leaves 208 bytes
of flash and 940 bytes for stack/local allocation, not a measured free-stack
minimum. The linked ELF contains no malloc/realloc/free allocator symbols.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R31 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
