# Pololu 3pi+ Standard line follower

Black-line-on-white profile for the **3pi+ 32U4 OLED Standard, 30:1 MP motors**,
with Safe/Mid/Beast modes, automatic calibration, a live alignment screen,
and an experimental three-lap learning/replay session on an unmarked closed loop.
Not for the original non-plus 3pi, Turtle, Hyper, or a modified drivetrain.
No external wiring or custom PCB is needed.

**R22: increase the healthy Beast map-planner envelope.**
R21 remained around 3.05 seconds with M dominant. M identifies the most frequent
limiting stage; it is not a fault or proof of a defective map. Earlier measured
learning scales were consistent (808-820 Q8), so there is no demonstrated reason
to slow the already slow first lap further.

- Healthy Beast planned deceleration is **250 PWM/s** instead of 225. This lets
  mapped straights carry more command before the braking region. The actual
  normal braking ramp remains **300 PWM/s**, and the roughly **70 mm + 60 ms**
  guard and **12.5%** drivetrain margin remain. This is a changed model
  assumption, not a measurement of physical braking ability.
- Healthy Beast lateral budget is **6000** instead of 5400 mm/s^2. Nominal
  lateral-limited corner speed increases about 5.4% before integer rounding
  and wheel/steering caps. At default scale, a 200 mm bend target rises from
  **230 to 243 PWM**. This does not establish measured speed or traction.
- Learning remains **80 PWM**. Safe, Mid, genuine noisy-learning fallback and
  weak geometry keep their R21 planner targets. Steering gains, output ramps,
  the 400 ceiling, exit-bin release, map contents and diagnostics remain.

This is performance tuning of the planner, not a claimed mapping-accuracy fix.
M can remain dominant during fast, successful laps. Compare lap times and line
retention; a different limiter letter is not the goal. R21 remains archived for
comparison and rollback. Physical R22 improvement and sub-three-second laps
have not been verified.

The map now integrates signed curvature by encoder distance within each 36 mm
bin, splitting readings at bin boundaries. It represents net turning instead
of storing the largest filtered steering excursion. Equal/opposite corrections
therefore do not permanently paint a sharp bend onto a straight. Stationary
samples add no map weight. Very slow positive movement still contributes to the
map; live yaw filtering retains its low-distance noise threshold. Small opposite
bends within one bin can cancel; this is a finite-resolution map, not exact track
geometry. Live curvature, line error, mismatch detection and fault stops remain.

With valid learned geometry and non-noisy learning, both Beast replay laps use
the corrected corner/braking envelope above. Replay tracking errors reduce speed
locally rather than permanently vetoing the rest of the session. Learning stays
at 80 PWM. P/D gains and forward-only motor bounds remain unchanged. Steering
priority at saturation remains, including its temporary inside-wheel trim.
These are experimental planning assumptions, not measured traction.

**Read the result diagnostics after testing:**

- The second screen row, for example `820/84`, is learned speed-scale Q8 /
  effective wheel width in mm. Divide the first number by 256 for the model
  ratio of mm/s per PWM. It is not measured top speed.

- `PWM 260/400` means peak actual wheel-average output / peak throttle before
  steering allocation. These are independent session maxima, not simultaneous
  measurements and not encoder speed. A large gap helps identify steering trim.
- `Limit: M` identifies the most frequent limiting stage during replay:
  **M** mapped-corner lookahead, **Y** live gyro-curvature bound, **L** optical
  line-error cap, **A** acceleration ramp, **S** steering headroom/trim,
  **F** profile cruise target satisfied.
  Tick-count ties choose M, L, A, S, F, then Y. This counts control ticks, not a
  measurement of lost time. `G` overrides the stage code when learned gyro
  geometry/polarity confidence is insufficient. `MID FALLBACK` overrides both
  after genuinely noisy learning.

The OLED remains blank during motion. Five numbered sensor readings (0 left,
4 right), alignment arrows and the centered indication remain before the run.
Redundant position/error text, sweep counters and stop captions were removed to
fit flash. The two-second arming pause still calibrates gyro bias; its screen
shows a static hands-clear/hold-still instruction instead of counting down.

The R22 Leonardo/OLED build uses **28,654/28,672 bytes flash** and **1,478/2,560 bytes
static RAM** with the pinned validation toolchain. Compiler/library changes can
change flash use; this build is near capacity. Focused checks pass. No full-track
models, hardware upload or physical R22 tests were performed. Neither faster
laps nor the 2.7-second goal are verified.

Extract the R22 ZIP, update both sketch files, upload and recalibrate. Compare
on the same floor/track and similar battery charge. Record laps 2/3, the new
speed-scale/width pair, PWM pair and limiter code for three sessions. Start each
session from the same position and heading. R21 remains archived for rollback.
Stop and revert if it departs the line or pitches; software bounds do not
establish physical stability.

**Without a physical marker, finish detection is an estimate, not an exact lap
counter.** Gyro drift, wheel slip, repeated geometry and nearby parallel sections
can prevent or fool localization. The software stops after three detected laps;
it cannot guarantee precisely three physical laps or a stop exactly on the line.
Use a distinct finish reference if exact counting is required.

This is experimental, not track-tuned competition firmware. Safe and Mid are
relative speed profiles, not guarantees of safe operation. Beast permits full
motor command on mapped straights; it retains braking and fault stops.
Compilation and simulated checks cannot guarantee that physical hardware will
not be damaged. Do the first runs on an open, flat floor, away from stairs.

## Install and upload

1. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` in the same sketch folder; update **both files together**.
   This revision shows **R22** on the startup screen, and
   refuses to compile with an older planner header.
2. Install **Pololu3piPlus32U4** using Library Manager; accept its dependencies.
3. Select **Arduino Leonardo** (ATmega32U4, 16 MHz), or install Pololu's board
   package and select **Pololu A-Star 32U4**. Select the robot's USB port.
4. This sketch targets the graphical OLED edition. Unused character-LCD support
   was removed in R8.
5. Upload. Uploading replaces the existing sketch; keep its source if needed.
   This project does not flash the robot automatically.

`releases/PololuLineFollower-R22.zip` packages both current sketch files and
these instructions. R21 and earlier releases remain in their corresponding release ZIPs.
`releases/PololuLineFollower-R12-backup.zip` preserves the
two source files from before this development pass for rollback.

Use four matching AAA NiMH rechargeable cells or four AAA alkaline cells in the
stock holder, with correct polarity. Do not substitute 10440 lithium cells.
The robot does not charge the cells through USB; use an appropriate charger.
Check that wheels turn freely and no wire touches a tyre. Keep the bumper
untouched while powering on: its sensors calibrate during startup.

## First run

1. Put a roughly 20 mm black tape line on a flat white **floor**. Use a broad,
   gentle, simple closed loop longer than one metre for initial tests. Choose
   a start point on a straight, away from crossings and nearby track sections.
   The estimator is unsuitable for tiny loops, branches or repeated returns to
   the same position and heading within a lap. Gaps/sharp corners may cause stops.
2. Power on with the bumper untouched. Motors stay off. Disconnect USB and
   place the robot approximately centred on a straight line section, pointing
   along the line. Leave clear space around it for turning.
3. Press and release **A**. After a two-second countdown, **the robot turns
   automatically** through five slow, encoder-bounded sweeps, with a stopped
   pause before each reversal. Keep hands clear. Any button cancels. The motion
   times out after eight seconds; each sweep also has a two-second limit.
4. After calibration, motors stop and the OLED shows the mode and live readings.
   If `Bad cal` appears, reposition on a clean black/white section and repeat A.
   Do not move the robot by hand during the automatic sweeps.
5. With the motors stopped, position it using the preview: aim for **Pos 2000,
   Err 0**, `CENTERED`, and the green LED. The five sensor rows run from **L0**
   (left) to **R4** (right); values range from **0 = white** to **1000 = black**.
   The centre indication allows an error of +/-100; start allows +/-350. `SHIFT
   LEFT/RIGHT` tells you which way to slide the robot. `NO LINE` or `WIDE/OFF` means the position is not a usable alignment
   reading. The display
   cannot determine heading: point the robot along the line as well.
6. While stopped, tap **C** to cycle **Safe -> Mid -> Beast -> Safe**. Power-on
   defaults to Safe. Verify a complete Safe session physically before trying Mid
   or Beast. Do not start with Beast on an untested track.
7. Press and release **B**. During the two-second countdown keep the robot
   completely still: it measures stationary gyro bias. Any button cancels.
8. **Lap 1 learns slowly in every mode.** On a plausible return to the initial
   pose, laps 2 and 3 use the map to plan speed. It remains a live line follower;
   it does not replay blind steering commands. The OLED stays blank throughout
   motion. Both Beast replay laps use sprint pacing when geometry is valid
   and learning was not noisy. Three lap times appear after stopping.
9. After the third detected lap, motors stop and the OLED shows three lap times
   plus PWM output/throttle peaks and the dominant replay limiter.
   It stays stopped until you explicitly start another session with B. A new
   session discards the previous map and learns again.
10. During calibration, arming, countdown or driving, **any A/B/C button stops
    movement** (the held initiating A/B is allowed during release-to-arm).
    C selects mode only while stopped. The power button is the fallback if the
    program becomes unresponsive. Never deliberately block a powered wheel.

After a fault or manual stop, release all buttons before pressing B to restart
from lap 1 at a chosen start point. An interrupted session is not resumed.
Sensor calibration is retained until A or a restart. No automatic restart or
blind spinning is used to recover a lost line.

## Modes and learning

All values below are PWM commands out of 400, **not measured speeds**.

| Stage/mode | Straight target | Motor ceiling |
| --- | ---: | ---: |
| Lap 1, all modes | 80 | 100 |
| Safe, laps 2-3 | 120 | 140 |
| Mid, laps 2-3 | 180 | 220 |
| Beast, laps 2-3 | 400 | 400 |

If Beast detects excessive line-reading changes during lap 1, it keeps Mid's
speed and steering envelope for both replay laps. This choice is latched until the next session; it cannot suddenly lower
the motor ceiling during a racing lap. Clean learning keeps the full Beast plan.
The bad-sample threshold is 150 filtered derivative units; fallback requires
a net score of eight bad samples, not one isolated spike. This fallback also uses earlier
200 PWM/s planned braking, the regular acceleration ramp, and gyro-confirmed
turn assistance limited by the measured bend. Optical entry anticipation is
disabled on this path. A sharp
learning turn can conservatively select the fallback even without sensor noise.

The 512-byte map stores signed curvature per 128 encoder counts, about
36 mm with the stock 32 mm wheels and 358.3 counts/revolution. It covers about
18.4 m, lives in RAM and is cleared at each new session/power-off. Signed gyro
curvature is integrated by distance into each bin. Alternating equal/opposite
turning therefore cancels instead of permanently recording its maximum excursion. Live line-error handling remains independent.

R6 distinguishes tighter corners instead of clipping all radii below about
236 mm to the same risk and the same 100 PWM corner target. Its curvature
encoding is `6000 / radius_mm`: a 75 mm bend is 80, 150 mm is 40, and 300 mm is
20, with a sign for direction and a separate unknown value.

Corner speed follows `v_corner^2 = lateral_budget * radius`, converted using
the measured speed/PWM ratio with a 12.5% margin. Safe/Mid use nominal budgets
of **1200/2400 mm/s^2**. Beast uses **6000** with learned geometry on both replay
laps, falling back to **3600** without it. Noisy-learning fallback uses Mid pace.
These are experimental tuning assumptions, not measured tyre friction or
guaranteed acceleration limits. Wheel ceilings
and available differential steering also constrain the target. Broad corners
can run faster than tight corners, and Beast has more corner authority than Mid.

On lap 1 the robot also estimates encoder speed per PWM on straights. Replay
uses the braking relation `v_allowed^2 = v_corner^2 + 2*a*distance`, with a
drivetrain margin and a guard for tracking delay. A distant bend limits speed
only when its braking distance requires it. The planner anticipates braking at
250 PWM/s (200 in noisy-learning fallback), below the normal output ramp's
300 PWM/s. The map floor is 65;
live sensing can reduce the target further for large errors or crossings.
This is an approximate drivetrain model, not a measured physical braking limit.

Learning also estimates effective wheel spacing and the gyro's yaw polarity
from paired encoder/gyro measurements accumulated across several samples. A
turn must accumulate at least 0.04 radians before a fit; weak measurements are
discarded after 20 samples. Unlike the old per-sample angle threshold, this works
at the slower learning pace and on broad bends. Invalid geometry is rejected
before conversion to an integer.

Replay uses the mapped desired curvature once live yaw agrees, or when the
forward line sensors confirm entry with at least 60 position units of error in
the mapped direction. Entry confidence ramps the desired turn, avoiding a full
steering step. Neighboring bins tolerate small position offsets. Opposing line
feedback fades stale turn assistance to zero on exit. Unknown geometry or
direction disables assistance. The line sensors remain active throughout.

R7 also uses the gyro to damp unwanted rotation during replay. Damping is stronger
when the current and next map bins confirm a straight and live curvature is low.
It reduces before a mapped bend or a large position error so corner entry remains
responsive. The damping uses learned gyro polarity, wheel spacing and motor scale;
it stays disabled until that learning is valid. R9's stronger corner budgets
require physical testing; the model does not measure available tyre grip.

Forward throttle has one shared ramp: up to 6 PWM per 10 ms accelerating,
and down to 3 PWM per 10 ms braking, scaled to the actual control interval.
R19 permits 15 PWM per 10 ms on confirmed, settled Beast replay straights;
all other conditions retain the 6 PWM ramp. The motor ceiling remains 400.
At 5 ms the fractional ramp alternates steps where necessary: ordinary braking
uses 1 then 2 PWM, retaining 300 PWM/s. Remainders reset at a target, direction
change, urgent recovery or stop, so unused ramp allowance cannot build up.
Steering is applied separately. Small position/derivative deadbands suppress
straight-line twitching, and small centred sensor noise no longer cuts throttle.
Healthy Beast replay prioritizes steering when the motor ceiling is reached:
the outside wheel holds the ceiling and the inside wheel slows. The shared
throttle target is retained for immediate recovery when the correction clears.
Other profiles preserve their shared average PWM and reserve steering headroom
through the throttle ramp. Differential correction is capped at
90 while learning/in Safe, 110 in Mid, and 140 in Beast,
with every wheel still bounded by its profile ceiling and forward-only output.
Beast can reach 400 on sufficiently long, well-tracked straights. A short straight
between tight corners must leave room to brake, so it cannot always reach 400.

Large tracking errors (700 position units or 250 filtered derivative units),
crossings, faults and the final session stop bypass routine soft braking.
The calibration ramp remains unchanged at at most 60 PWM. These command limits
do not measure pitch, current, torque or physical deceleration, and cannot
guarantee the rear will never lift.

The session remains best-of-three: lap 1 learns, laps 2 and 3 race. Healthy Beast
uses the same sprint envelope on both replay laps. Line tracking, crossings and
live curvature continuously constrain speed, without a whole-session replay
veto. A fault never silently adds another lap.
The third estimated crossing immediately
commands both motors to zero before updating the screen. The stock DRV8838
drivers brake at zero command ([driver documentation](https://www.pololu.com/product/2990));
physical stopping distance is still nonzero. Keep clear floor beyond the estimated
finish. Speed estimation is retained across continuous lap transitions, and
lookahead visits bin zero correctly when the final map bin is partial.
Actual lap times still depend on tracking, grip and estimated crossing accuracy.

Wheel distance and integrated gyro heading estimate planar position. A lap is
accepted after leaving the start area and crossing the initial starting plane
forward, within 80 mm sideways and about 14 degrees of the original heading.
After lap 1, a return must also agree with learned distance within 15%. Each
estimated return anchors the next lap. These are engineering tolerances, not
proof of being at the actual start. A miss stops on distance/time bounds instead
of being counted using elapsed time alone.

## Protections and limits

- Profile-specific ceilings apply on every line-following output. Motor commands
  do not directly limit current, torque or temperature.
- Forward-only line following, shared acceleration/braking ramps, immediate
  fault stops and urgent tracking recovery.
- Automatic calibration uses opposite wheel directions at **at most 60/400**,
  acceleration ramps, independent wheel travel limits and 150 ms stopped pauses
  before reversals. Encoders check for stalls, direction errors and read errors.
  Calibration is accepted only if every sensor records enough black/white range.
- Calibration and line following require a released button and countdown;
  neither starts moving immediately on power-up or while the start button is held.
- The OLED preview refreshes at 10 Hz while stopped, preserving the stop reason.
  There are no display writes during driving, including lap transitions. The
  complete results screen is written only after commanding both motors to zero.
- The startup screen shows battery voltage and button instructions. Calibration
  shows sweep progress; the countdown changes from 2 to 1. The screen is cleared
  before motion and remains blank until stopped. This blanks pixels; it does not
  switch off the OLED power supply. Faster sensing is not a battery-saving claim.
- Learned turns receive distance-based prebraking. Current line offset and its
  rate of change can reduce the target further. Steering stays active during
  braking, and routine changes preserve the shared average motor command.
- Start requires line calibration, a centred line, no USB power, no bumper
  contact, a working IMU and sufficient stable stationary gyro samples.
- The robot ignores bumper contact during line following so floor contact during
  braking cannot trigger `Bumped`. Startup, arming, countdown and calibration
  still check the bumper. Set `Settings::STOP_ON_TRACK_BUMP` to `true` to restore
  the running bumper stop. This change does not prevent nose dips or soften braking.
- Stops on lost line, USB connection, battery reading outside
  **4.4..6.6 V**, wrong encoder direction, encoder error, sustained lack of wheel
  movement or a control-loop delay over 50 ms. Added stops cover stale/failed
  gyro data, I2C timeouts, impossible motion, map capacity/gaps/mismatch, a missing
  estimated finish (90 seconds per lap), or the four-minute session backup limit.
  Replay also stops if distance exceeds the learned lap by 15% without a return.
- Four or more dark sensors are treated as a crossing: continue straight slowly
  for up to 200 ms, then stop. Wide markers/slow crossings may cause a safe stop.
- A 250 ms hardware watchdog requests a reset if the main loop hangs during
  battery-powered operation. It is disabled for normal USB-connected use and
  leaves Arduino's 1200-baud upload reset alone. Startup returns to motors-off
  idle and requires calibration and a new start.

These checks are best effort. Running bumper stops are disabled; encoders cannot
detect spinning wheels or every partial stall; the robot has no motor-current
or motor-temperature measurement. It has no guaranteed fall/edge detection.
The darkness check can also react to lifting; do not lift a running robot.

## Display messages

| Message | Action |
| --- | --- |
| `USB out` | Disconnect USB before starting. |
| `Cal A!` / `Bad cal` | Press A and calibrate over both surfaces. |
| `Cal time` | Check clear wheels, battery condition and calibration placement. |
| `Centre!` / `No line` | Check line, calibration and starting position. |
| `Bat low` / `Bat high` | Power off; check the four cells and their type. |
| `Bumped` | Bumper contact before driving or during calibration; release and inspect it before retrying. |
| `Stalled` | Power off; check free wheels, gearbox, batteries and encoder wiring. |
| `Enc dir` / `Enc err` | Stop testing; check assembly/model and encoders. |
| `Dark/air` | Check floor, crossings, sensor height and calibration. |
| `Loop lag` | Keep motors stopped and investigate timing/code changes. |
| `Hold still` / `Gyro cal` | Keep the robot still throughout the B countdown. |
| `IMU error` / `Gyro stale` / `Gyro range` | Power off; inspect IMU/I2C and physical motion. |
| `Map full` / `Map gap` / `Map mismatch` | Session aborted; inspect track, grip and map limits. |
| `No finish` | Return estimate failed, loop is too short, or lap distance/time exceeded bounds. |
| `Motion error` | Encoder/gyro motion was outside estimator limits; investigate before retrying. |
| `Time end` / `Stopped` | Session stopped; reposition and B starts a fresh learning lap. |
| `3 LAPS EST. DONE` | Three estimated laps completed; motors stay stopped. |

## Tuning after successful physical tests

Profile limits and map tolerances are in `RaceSession.h`; control/calibration
settings are at the top of the sketch. First verify several repeatable complete
Safe sessions, including correct physical lap counting and stopping. Then tune
P/D, grip and alignment based on actual track observations.
The PD algorithm filters the derivative and normalizes it to a 10 ms reference
using microsecond acquisition timestamps, with reduced forward speed when the line is far from centre or moving
rapidly across the sensors. A
sensor/control cycle may take longer; the program does not
claim a hard real-time guarantee. Encoders provide odometry and stall/direction
checks, not closed-loop wheel-speed control in this version.

Calibration remains capped at 60/400 regardless of mode. If it oscillates,
misses the return or loses the line, stay in Safe and inspect/tune before trying
faster profiles. Beast is full-output experimental operation and cannot promise
collision prevention or motor/gearbox protection. Do not disable fault stops to
force it to finish. Add a distinct finish reference if estimated lap counts are
not repeatable enough. Sharp corners, wide junctions and gaps need track testing.

The most useful next experiments are:

- Measure and tune the braking guard and deceleration for the actual tyres and
  surface. Preventing nose contact and urgent recovery is a priority before
  raising corner speeds. Removing the bumper stop does not resolve pitching.
- Record `Fast tick max` after Beast runs. Compare 5 and 10 ms using only
  `FAST_CONTROL_MS`; assess physical stability and lap times at similar charge.
- Add closed-loop wheel-speed control using the existing encoders to compensate
  unequal motors. It needs anti-windup at the 400-PWM ceiling and deliberate
  coordination with the line controller, so it is not part of R19.
- Keep tyres and track clean, check wheel alignment and free movement, and use
  the same floor and lighting for calibration and timed comparisons. Avoid adding
  decorative bodywork or ballast without measurements.
- Add a reliable start/finish reference if allowed by the rules. That enables
  repeatable lap measurements and can reduce reliance on pose integration.

Beast already requests the full permitted motor command on clear straights.
Pololu lists about 1.5 m/s for the stock Standard drivetrain
([motor documentation](https://www.pololu.com/docs/0J83/5.3)). Software can improve
time spent near that speed; deleting more idle-screen code will not raise the
drivetrain's physical top speed.

## Validation

**R19 check:** `python tests/run_tests.py --focused` compiles the actual sketch
against fake hardware and checks startup/calibration, UI, modes, motor limits,
buttons/faults, watchdog/upload handoff, fast scheduling, fractional ramps at
5/7/8/10/20/40 ms, mode transitions, emergency bypass, local speed recovery, gyro timing,
microsecond acquisition jitter, saturation, both timer wraps and the final stop
latch. A dense per-encoder-count oracle checks 256 planner states, including
unknown bins, repeated/opposite bends, partial/exact wrap and all modes, without
simulating a moving robot. Corner-exit checks cover both gyro signs, both turn
directions, wheel widths 60/86/110 mm, multiple base commands, monotonic release,
unchanged mapped-entry/bend assistance and stale/unknown turn rejection.
New checks verify immediate steering in both directions at full throttle,
recovery without throttle ratcheting, peak-output reporting, sprint corner
targets on both replay laps, all five limiter reports and recovery after a
large transient error. Spatial-map checks cover cancellation, signed turns,
boundary splitting, stationary samples, tiny movements, sample-size invariance
and retention of a real short corner.
R19 also compares 256 static planner states against archived formulas:
healthy Beast stays below the R17 envelope and within a 5% + 1 PWM bound
of R18 targets; other envelopes are unchanged.
Corner-entry checks cover both turn signs and approach speeds 500/1000/1500 mm/s:
prebraking starts earlier, targets decrease toward the bend, the corner target
is reached inside the delay guard, and sufficiently long straights still allow
400 PWM. Added phase-error checks put the mapped corner two bins (about 72 mm)
late: the planner still requests corner pace 40 ms before the physical entry at
all three tested speeds. Gyro checks cover 256 combinations of both polarities,
both turn directions, correct/opposite yaw, error thresholds 159/160/399/400,
Safe/Mid/Beast and noisy-learning fallback. They verify the modified Beast
response and unchanged other-profile/wrong-direction damping. These are software
checks, not a physical stopping-distance or grip validation.
New noise tests cover isolated spikes, recovered seven-sample bursts, both
threshold signs, sustained noise, score saturation, fallback latching, reset,
stopped/replay isolation, and real-sketch noisy sensor sequences. Footer checks
cover geometry confidence at -4/-3/0/3/4 votes. Fractional acceleration at 15
PWM/10 ms is checked across short and irregular intervals.
Real OLED compilation is checked separately.
The full-track tests below are retained as optional historical regressions and
were **not run for R19**. Their retained 10 ms motion-model timestep does not
characterize the new 5 ms dynamics. There is no measured R19 lap time yet.

`python tests/run_tests.py` builds and runs the optional simulated tests of the actual sketch
using a native C++ compiler. These tests check calibration travel and pauses,
OLED layout/countdown/alignment output, modes, real sketch output at every replay
ceiling, independent map/live limits, earned lap-3 pacing, braking envelopes,
filtered curvature, learned speed scale, map bounds/mismatch, CW/CCW loop closure,
the three-lap stop latch, gyro faults, rollover, cancellation and the existing
stop paths. Bumper regressions check that held contact is ignored while driving
in every mode, while startup/calibration/countdown checks and button stops remain
active. A differential-drive rounded-square model feeds encoder, gyro and
line-position readings back from commanded motor motion. Seventy-two cases cover all
three modes, four corner radii, both directions, two motor-response scales,
noisy long straights, reversed gyro polarity, different effective wheel spacing,
unequal motor response, slower/faster motor response, and broad-turn calibration
with either gyro polarity.
Additional regressions check monotonic corner limits, geometry learning,
feedforward vetoes, throttle recovery under
alternating sensor errors and ramp rates at 10/20/40 ms control intervals;
each must complete three laps, keep replay distances consistent, run both replay
laps faster than learning, and avoid a lap-3 penalty beyond 100 ms of quantization
tolerance. Long-straight cases must reach at least 360 PWM, brake before corners,
and limit normal common-throttle drops to 3 PWM per 10 ms. Every replay motion
case retains that normal-braking bound. Tight-corner cases
must also stay within that braking rate and 8 mm model line error. These are
idealized models, not proof of real-track performance:
they do not reproduce real tyres, slip, braking distance, reflectance physics,
bus timing or bootloader resets.

The suite also checks that no display writes occur across running lap transitions
and exercises eighteen acceleration cases covering learning, both slower modes,
quiet Beast replay, large line error, derivative noise, live curvature and the
noisy-learning fallback. A separate
150,000-state comparison with frozen R7b confirmed identical braking targets
after the lookahead optimization. Lookahead now wraps its position incrementally
and stops when even the minimum corner speed can no longer constrain the target.
The comparison reduced corner-limit evaluations from 1,845,671 to 613,546;
this measures calculation counts, not AVR execution time or a lap-speed gain.

R9 adds actual sketch regressions for the last sample of lap 2, earned attack
arming, permanent disarming, and no extra laps. Geometry tests cover tiny turn
samples, both gyro signs, timeout flushing and out-of-range float rejection.
Predictive steering tests cover entry thresholds, confidence boundaries, maximum
AVR products, stale opposing turns, unknown bins and unlearned geometry.
Twenty-five additional full-course cases use five noise seeds at 175/200 position
units across broad/tight bends, long straights and unequal motors. They retain
the existing braking, distance and lap-time bounds. Actual sketch tests exercise
learning-noise detection, fixed replay limits and disabled bonus acceleration;
planner tests cover threshold signs, reset, mode isolation and attack exclusion.
These checks do not measure AVR loop timing.

Eight additional straight-line simulations exercise sensor noise, unequal motors,
control-period variation and delayed optical readings. With 3% motor mismatch and
sensor noise, R7 reduces steady physical position variation from 0.96 to 0.21 mm
in the model, compared with frozen R6. This is a simulated stability comparison,
not a prediction of real-track accuracy. Full-course checks retain their existing
distance, braking and lap-time requirements.

For the approximate 600 mm straights / 200 mm radius track, the frozen R5 and R6
controllers are compared with identical motor models and distance checks. With
the faster motor model, Beast replay changes from **7.43 s to 4.50 s**; with the
other model, **10.65 s to 4.76 s**. Tests require at least 20% improvement over
R5 and a 15% gap from Mid on those cases. These simulated gains do not predict
the user's physical lap time.

The Arduino sketch must also be compiled with the real Pololu library for
`arduino:avr:leonardo`, using the OLED configuration. No robot was flashed
or physically tested during development.

R9 is built with Arduino AVR core 1.8.8, Pololu3piPlus32U4 1.1.3
and PololuOLED 2.0.0. It initializes the used 21x8 OLED layout directly through
public library methods, avoiding retention of the unused 8x2 renderer. No library
files are modified. Flash remains tight: extra debug messages or different
library versions can exceed capacity.
The verified OLED build uses **28,596/28,672 bytes of flash** and **1,445/2,560
bytes of static RAM**, leaving 1,115 bytes for stack/local allocation.

On the 600 mm straight / 200 mm radius simulated track with the faster motor
model, R9 takes 12.31 s to learn and 3.56/3.03 s for replay, versus R8's
4.48/4.42 s replay. With the slower model, best replay changes from 4.61 to
4.21 s. Regression targets require at least 20% and 5% improvement respectively,
while retaining braking, distance and line-error bounds. Ungated acceleration,
reduced uncertainty margins and less stable steering variants were rejected.
These are model results, not measured robot lap times. The requested physical
2.7-second result has not been demonstrated.

The sketch includes only the Pololu hardware components it uses, avoiding the
unused buzzer timer interrupt and keeping the OLED build within flash capacity.

## References

- [Pololu user guide](https://www.pololu.com/docs/0J83/all)
- [Encoder resolution](https://www.pololu.com/docs/0J83/5.4)
- [IMU and gyro](https://www.pololu.com/docs/0J83/5.6)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [Official Standard-edition line-following example](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library/blob/master/examples/LineFollowerPID/LineFollowerPID.ino)
