# Pololu 3pi+ Standard line follower

**R36 — a bounded Beast pace increase, with R34 steering retained.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
white floor. Keep both sketch files together. Previous release ZIPs remain
available for comparison and rollback.

## What changed

- **Faster mapped corners:** qualified Beast's nominal lateral budget rises from
  6000 to 6300 mm/s² (+5%). Where lateral acceleration is the limiting factor,
  this permits approximately 2.5% more speed. Wheel/steering ceilings still
  apply. This raises requested corner speed; actual tire grip is unmeasured.
- **Faster straight recovery:** after 40 ms of quiet measured yaw, a pure mapped
  straight with error <160, derivative <60 and projected error <200 can ramp at
  1800 instead of 1500 PWM/s. Signed values are tested symmetrically. Trailing
  corner bins retain their stricter 1500 PWM/s qualification; other recovery
  remains 600 PWM/s. Fresh turning, the next mapped bend, crossings, noisy
  fallback and untrusted geometry revoke the straight boost.
- **Less conservative approach planning:** qualified Beast plans braking at
  approximately 280 instead of 250 PWM/s. Routine output braking stays at
  300 PWM/s. The approximately 88 mm + 60 ms entry guard is retained, including
  late-map tests. This uses more of the existing braking allowance, with less
  reserve between the planned and commanded ramps.

Safe/Mid, noisy fallback and untrusted-geometry corner/braking models retain
R35's values. R24 optical gains and gyro damping, the 400 PWM ceiling, fixed
sensor calibration, three estimated laps, running OLED silence and fault stops
remain. No map peaks were erased, and no new Arduino dependencies were added.
The R35 calculation cache and its invalidation checks remain.

## Validation and limits

- Native focused checks pass, including mode/geometry/cache combinations,
  dense planner comparisons, fractional ramps, late maps, strict exit gates,
  buttons, battery/IMU/encoder faults and bounded corner-speed increases.
- Actual Leonardo build: **28,000 / 28,672 bytes flash**, **1505 / 2560 bytes
  static RAM**, leaving 1055 bytes for stack/locals. No allocator symbols are
  linked. Stack peak and physical control-loop latency have not been measured.
- Paired R35/R36 comparisons cover 20 motion cases plus a command fixture at
  both 5 ms and 10 ms replay intervals. All motion cases complete with both
  versions. Cases include both directions, noise, motor imbalance/response,
  wheel spacing, smaller corners and one-bin map shifts. Command recovery in
  the fixed-input fixture improves from 70 to 60 ms.
- The four main 5 ms rounded-square cases improve by about **1.9–2.7%** per
  racing lap. Wider stress results are mixed: some laps are slower and some
  tracking offsets increase. These models have no calibrated tire friction,
  battery sag or physical pitching, and cannot establish real lap times or
  completion reliability.

Compare several R35/R36 sessions at similar charge and placement. Record both
racing laps and every failed attempt. Consistent sub-three-second physical laps
remain a track-test goal. Keep R34/R35 available if the higher corner requests
exceed your track's grip.

## Install and upload

1. Extract `releases/PololuLineFollower-R36.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R36**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe â†’ Mid â†’ Beast â†’ Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and filtered error derivative. The nominal lateral budgets are 1200/2400/6300 mm/sÂ² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Both replay laps use the same budget. Wheel ceilings and
differential steering room also constrain speed. No reverse wheel commands are used during line following.

Planned braking is approximately 280 PWM/s for qualified Beast, 250 for other
normal profiles, or 200 for noisy-learning fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

The R35 cache checks remain. R36 adds bounds on the increased Beast corner
requests and verifies the 280 PWM/s braking envelope. Safe/Mid/noisy/untrusted
models are compared to the prior revision. Existing calibration, UI, motor,
map, timing and fault checks remain enabled. Late-map tests retain three bins
of delay with 20 ms lead, or two bins with 40 ms lead. These are requested
limits, not measured physical stopping margins.

Run the paired models separately:

```powershell
python tests/compare_motion.py --baseline R35 --stress --output releases/PololuLineFollower-R36-motion.json
python tests/compare_motion.py --baseline R35 --stress --period-ms 10 --output releases/PololuLineFollower-R36-motion-10ms.json
```

The same current harness compiles against frozen R35 and current firmware.
Learning uses 10 ms steps; replay uses the selected interval, with a separate
10-20 ms jitter/delayed-sensor case. Motor response is adjusted for elapsed
time. Comparison mode records outcomes without imposing historical lap-time
or soft-brake expectations. Physical faults remain active. The full historical
trajectory suite was not run. Both paired reports are included in the R36 ZIP.

The actual OLED/Leonardo build passes with warnings enabled:
**28,000/28,672 bytes flash; 1,505/2,560 bytes static RAM**. This leaves 672 bytes
of flash and 1,055 bytes for stack/local allocation, not a measured free-stack
minimum. No malloc/calloc/realloc/free allocator symbols are linked.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R36 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
