# Pololu 3pi+ Standard line follower

**R28 — recover approach/exit speed within the R27 corner envelope.** For the
stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on a white
floor. Two source files, no new libraries. Earlier releases remain archived.

## What changed

R27 was reported slower; lap times and limiter shares were not provided.
R28 makes two targeted changes while keeping its full mapped-corner hold:

- **Less conservative approach:** qualified Beast plans braking at **225 PWM/s**,
  between R27's 200 and R26's 250. This permits a higher approach target while
  retaining R27's full entry guard (about 106 mm + 80 ms of travel), corner
  target and actual 300 PWM/s routine braking ramp.
- **Earlier acceleration after a confirmed exit:** after 40 ms of quiet moving
  raw yaw, with both current and next map bins straight, the remaining filtered
  yaw may be below **64 Q3 units**, previously 32. This tolerates more of an old
  filter tail. Fresh turning resets qualification and blocks the boost before
  the slower filter catches up. No boost inside a mapped bend.

The 5400 mm/s² nominal Beast corner budget, final-bin speed cap, maximum
1500 PWM/s launch ramp, projected line-error control, steering gains, 400 PWM
ceiling, Safe/Mid/learning/fallback behavior and fault stops retain R27 settings.
Both replay laps use the same policy; OLED updates stay off during motion.

Focused planner checks compare R27 ≤ R28 ≤ R26 requested speeds on sampled
states, verify higher approach targets on a fixed bend, and retain the same
230-PWM corner target in the default fixture. The earlier-entry checks with
three late map bins still pass. These are software target checks, not measured
physical speed or proof of reliable corners. No lap-time gain, completion rate
or 2.7-second result is claimed before your track tests.

For the next test, record laps 2/3, completion count, `LIMIT`, `A/L/S` shares and
PWM at similar battery charge. Those distinguish braking, acceleration, line
tracking and steering limits before another tuning change.

## Install and upload

1. Extract `releases/PololuLineFollower-R28.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R28**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe → Mid → Beast → Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and the new A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and projected error. The nominal lateral budgets are 1200/2400/5400 mm/s² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Wheel ceilings and differential steering room also constrain
speed. No reverse wheel commands are used during line following.

Planned braking is 225 PWM/s for qualified Beast, 200 for noisy-learning
fallback, or 250 for other profiles.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and cover calibration,
startup/UI/buttons, all mode ceilings, battery/USB/IMU/encoder/stall faults,
watchdog upload handoff, fractional ramps and timing rollover, predictive line
limits, yaw feedback, mapped exit permissions, motor allocation, local recovery,
limiter shares and the three-lap stop latch. A dense-distance oracle checks the
revised mapped speed/braking targets against both R27 and R26 envelopes. New calibration checks cover per-sensor
outliers, all-ten-readings extrema, repeated resets, storage ownership and span
rejection. New acceleration checks cover signed input bounds, symmetry, monotonic
fade, both replay laps, short/irregular ticks and braking remainder reset.
Corner regressions retain the final mapped bend bin, require 40 ms of moving
quiet yaw before a boost, reject stationary qualification, and test a map
shifted three bins late at 500/1000/1500 mm/s using fixed planner inputs.

The optional historical trajectory models are retained in the tests but were
**not run for R28**. They do not characterize the physical robot.

The actual OLED/Leonardo build passes with warnings enabled:
**27,554/28,672 bytes flash; 1,491/2,560 bytes static RAM**. This leaves 1118 bytes
of flash and 1069 bytes for stack/local allocation, not a measured free-stack
minimum. The linked ELF contains no malloc/realloc/free allocator symbols.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R28 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
