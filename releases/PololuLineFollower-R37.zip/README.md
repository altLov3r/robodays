# Pololu 3pi+ Standard line follower

**R37 - controlled corner exits, stronger boost after alignment.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
white floor. Keep both sketch files together. Earlier releases remain available.

## What changed

- **Continuous straight qualification:** a trailing curved map bin cannot enable
  straight boost. After 40 ms of quiet raw yaw, an actual mapped straight must
  accumulate 40 ms of acceptable optical readings. Each sample contributes at
  most 10 ms, so a single late sample cannot enable boost. Acquisition requires
  |error|<160, |derivative|<60 and |error + 3*derivative|<200 in sensor units.
  Once qualified, hold thresholds are 180/80/240 to avoid small-noise chatter.
  Turning, an upcoming mapped bend, a crossing or excessive tracking error
  resets qualification immediately. New sessions and aborts clear it too.
- **Stronger qualified launch:** 2400 instead of 1800 PWM/s (+33%), after the
  alignment gate. Rejoining uses 600 PWM/s. The straight target and each motor
  ceiling remain **400 PWM**, including future-corner braking constraints.
- **Actual throttle-restoration ramp:** the previous wheel-average command now
  bounds positive output increases. Removing steering trim cannot dump hidden
  common throttle into the motors, even on the tick boost first qualifies.
  The internal common ramp remains independent of alternating steering, and
  routine braking retains its separate 300 PWM/s setting.
- **Less straight derivative chatter:** small optical corrections on mapped
  straights with full gyro damping use D=64/256 instead of 96/256. Corners,
  larger tracking disturbances and other modes retain the existing gain.
  Turn assistance now scales with previously delivered wheel-average PWM,
  preventing hidden throttle from exaggerating its requested turn.

R36's corner budget, planned braking, entry guard and wheel/steering ceilings
remain. Sensor calibration, three estimated laps, running OLED silence and
battery/USB/button/IMU/encoder/stall stops remain. No new Arduino dependencies.

## Validation and limits

- Native regression checks pass, including new rebound, delayed sample,
  hysteresis, hidden-throttle, boost-transition and turn-assistance cases.
- In the paired exit fixture, R36 restores **280->400 PWM** in one 5 ms tick;
  R37 requests **280->283**. At qualification, another fixture verifies
  **300->312**, with no jump to its hidden 400 PWM command.
- An already qualified straight fixture reaches 300 from 200 PWM in **45 ms**
  versus R36's 60 ms. An unqualified exit deliberately takes longer to boost.
- Paired R36/R37 models cover 22 motion cases, a command fixture and a hidden
  throttle fixture at each of 5 ms and 10 ms replay intervals. Both versions
  finish every motion case. Residual-turn rejoin cases are included in both
  directions. Lap times and tracking offsets are mixed: many ordinary square
  laps are slightly slower, while some noisy cases improve. This release does
  not establish a general lap-time or stability improvement on the real robot.
- Leonardo build: **28,498/28,672 bytes flash**, **1506/2560 static RAM**.
  That leaves 174 bytes flash and 1054 bytes for stack/locals. No linked heap
  allocators. Peak stack, loop latency, grip, pitching and battery sag remain
  unmeasured; the models cannot validate those physical effects.

First verify a Safe session, then compare Beast sessions at similar charge and
placement. Check the reported exit/rebound problem before judging fastest lap
speed. Record both racing laps and failed attempts. Keep R35/R36 for rollback.

## Install and upload

1. Extract `releases/PololuLineFollower-R37.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R37**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe â†’ Mid â†’ Beast â†’ Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and filtered error derivative. The nominal lateral budgets are 1200/2400/6300 mm/sÂ² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Both replay laps use the same budget. Wheel ceilings and
differential steering room also constrain speed. No reverse wheel commands are used during line following.

Planned braking is approximately 280 PWM/s for qualified Beast, 250 for other
normal profiles, or 200 for noisy-learning fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration or throttle restoration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

The planner's R36 speed envelope and late-map checks remain. The added
`test_corner_exit.cpp` checks continuous qualification, acquisition/hold limits,
reset, actual output release, the qualification transition, settled full-speed
launch, delivered-base assistance and straight/corner derivative gains.

Run paired models separately:

```powershell
python tests/compare_motion.py --baseline R36 --stress --output releases/PololuLineFollower-R37-motion.json
python tests/compare_motion.py --baseline R36 --stress --period-ms 10 --output releases/PololuLineFollower-R37-motion-10ms.json
```

The same current harness compiles against frozen R36 and current firmware.
Learning uses 10 ms steps; replay uses the selected interval, plus a 10-20 ms
jitter/delayed-sensor case. Motor response adjusts for elapsed time. Rejoin
fixtures start with a near-centered sensor, residual heading/yaw and excess
internal throttle. Comparisons retain physical-fault software stops without
imposing historical timing expectations. The full historical trajectory suite
was not run. Both comparison reports are included in the R37 ZIP.

The warnings-enabled OLED/Leonardo build uses **28,498/28,672 bytes flash** and
**1506/2560 bytes static RAM**. No malloc/calloc/realloc/free symbols are linked.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R37 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
