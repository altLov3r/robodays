#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>

constexpr uint8_t RACE_PLANNER_REVISION = 12;

enum DriveMode : uint8_t { SAFE, MID, BEAST };

struct DriveProfile
{
  int16_t cruise;
  int16_t limit;
};

inline DriveProfile driveProfile(DriveMode mode, bool learning)
{
  if (learning) { return {80, 100}; }
  if (mode == MID) { return {180, 220}; }
  if (mode == BEAST) { return {400, 400}; }
  return {120, 140};
}

// Distance-indexed signed curvature, without an absolute position reference.
// Loop closure is an estimate: wheel slip/gyro drift can prevent or fool it.
class RaceSession
{
public:
  static constexpr uint16_t BIN_COUNTS = 128;
  static constexpr uint16_t MAP_CAPACITY = 512;
  static constexpr uint32_t LAP_TIMEOUT_MS = 90000;
  static constexpr float MM_PER_COUNT = 32.0f * 3.14159265f / 358.3f;
  static constexpr int8_t UNKNOWN_CURVE = -128;
  enum Fault : uint8_t { NONE, MAP_FULL, MAP_GAP, MAP_MISMATCH, NO_FINISH, BAD_MOTION };
  enum Event : uint8_t { NO_EVENT, LAP_FINISHED, SESSION_FINISHED };

  DriveMode mode = SAFE;
  Fault fault = NONE;
  bool running = false;
  bool mapReady = false;
  uint8_t completed = 0;
  uint32_t lapTimes[3] = {};
  uint32_t learnedCounts = 0;
  uint16_t binsUsed = 0;
  int8_t curves[MAP_CAPACITY]; // Signed curvature * 6000: radius 75 mm is +/-80.
  uint32_t distanceTwice = 0;
  uint32_t lapStarted = 0;
  float x = 0, y = 0, heading = 0, speedMmS = 0;
  bool leftStartZone = false;
  bool returnArmed = false;
  uint16_t mismatchMs = 0;
  int16_t filteredCurve = 0; // Curvature in eighths to retain filter precision.
  uint16_t speedScaleQ8 = 1024; // Measured mm/s per PWM, initially 4.0.
  uint8_t trackWidthMm = 86;
  int8_t turnVotes = 0;
  int16_t learningDifference = 0;
  float learningTurn = 0;
  uint8_t learningSamples = 0;
  bool cleanReplay = true;
  bool attackLap = false;
  bool noisyLearning = false;

  void reset(DriveMode selected, uint32_t now)
  {
    mode = selected;
    fault = NONE;
    running = true;
    mapReady = false;
    completed = 0;
    learnedCounts = 0;
    binsUsed = 0;
    speedMmS = 0;
    filteredCurve = 0;
    speedScaleQ8 = 1024;
    trackWidthMm = 86;
    turnVotes = 0;
    learningDifference = 0;
    learningTurn = 0;
    learningSamples = 0;
    cleanReplay = true;
    attackLap = false;
    noisyLearning = false;
    memset(curves, 128, sizeof(curves));
    memset(lapTimes, 0, sizeof(lapTimes));
    resetLap(now);
  }

  void abort()
  {
    running = false;
    attackLap = false;
    if (completed < 3) { mapReady = false; }
  }

  DriveProfile profile() const { return driveProfile(noisyLearning ? MID : mode, !mapReady); }
  int16_t steeringLimit() const
  { return !mapReady ? 90 : (noisyLearning ? 110 : (mode == BEAST ? 140 : (mode == MID ? 110 : 90))); }
  uint32_t distanceCounts() const { return distanceTwice / 2; }

  void noteTracking(int16_t error, int16_t delta, bool crossing)
  {
    // Select a conservative envelope during learning, never mid-replay.
    if (running && !mapReady && mode == BEAST && abs(delta) >= 150) { noisyLearning = true; }
    if (!running || !mapReady || mode != BEAST) { return; }
    if (crossing || abs(error) >= 400 || abs(delta) >= 180)
    {
      if (completed == 1) { cleanReplay = false; }
      attackLap = false; // A degraded final lap cannot re-arm itself.
    }
  }

  void resetLap(uint32_t now)
  {
    distanceTwice = 0;
    lapStarted = now;
    x = y = heading = 0;
    leftStartZone = returnArmed = false;
    mismatchMs = 0;
  }

  Event update(int16_t left, int16_t right, float turnRadians,
    uint16_t elapsedMs, int16_t drivePwm, uint32_t now)
  {
    if (!running || fault != NONE || completed >= 3) { return NO_EVENT; }
    if (!elapsedMs || elapsedMs > 50 || left < -2 || right < -2 ||
      left > 500 || right > 500 || !isfinite(turnRadians) || fabsf(turnRadians) > 0.7f)
    {
      fault = BAD_MOTION;
      return NO_EVENT;
    }
    if (now - lapStarted >= LAP_TIMEOUT_MS)
    {
      fault = NO_FINISH;
      return NO_EVENT;
    }
    int32_t sum = static_cast<int32_t>(left) + right;
    if (sum < 0) { sum = 0; }
    distanceTwice += sum;
    const float step = sum * 0.5f * MM_PER_COUNT;
    // Encoder quantization must not make the braking horizon jump every sample.
    speedMmS += (step * 1000.0f / elapsedMs - speedMmS) * 0.25f;
    const float previousX = x;
    x += step * cosf(heading + turnRadians * 0.5f);
    y += step * sinf(heading + turnRadians * 0.5f);
    heading += turnRadians;
    if (heading > 3.14159265f) { heading -= 6.28318530f; }
    if (heading < -3.14159265f) { heading += 6.28318530f; }

    // Filter signed curvature: alternating steering jitter is not a sustained bend.
    float curve = step >= 0.5f ? turnRadians * 48000.0f / step : 0;
    if (curve > 1016) { curve = 1016; }
    if (curve < -1016) { curve = -1016; }
    filteredCurve += (static_cast<int16_t>(curve) - filteredCurve) / 4;
    const int8_t bend = filteredCurve / 8;
    const uint8_t magnitude = abs(bend);
    const uint32_t distance = distanceCounts();
    if (!mapReady)
    {
      // Estimate the stock drivetrain's speed scale on settled learning straights.
      if (magnitude <= 3 && drivePwm >= 80 && speedMmS > 100)
      {
        const uint16_t sample = static_cast<uint32_t>(speedMmS) * 256 / drivePwm;
        if (sample >= 256 && sample <= 1536)
        { speedScaleQ8 = (speedScaleQ8 * 7 + sample) / 8; }
      }
      // Learn yaw polarity and effective wheel spacing from encoder/gyro agreement.
      // Do not assume the simulator's axis convention or exact tyre geometry.
      // Integrate paired measurements: slow/broad turns are below the per-tick
      // angle threshold, and single encoder counts otherwise bias the width.
      if (magnitude >= 8)
      {
        learningDifference += left - right;
        learningTurn += turnRadians;
        learningSamples++;
        if (fabsf(learningTurn) >= 0.04f || learningSamples >= 20)
        {
          if (fabsf(learningTurn) >= 0.04f)
          {
            const float width = learningDifference * MM_PER_COUNT / learningTurn;
            const float magnitudeWidth = fabsf(width);
            if (magnitudeWidth >= 59.5f && magnitudeWidth < 110.5f)
            {
              const uint16_t sample = static_cast<uint16_t>(magnitudeWidth + 0.5f);
              trackWidthMm = (trackWidthMm * 7 + sample + 4) / 8;
              if (width > 0 && turnVotes < 8) { turnVotes++; }
              if (width < 0 && turnVotes > -8) { turnVotes--; }
            }
          }
          learningDifference = 0;
          learningTurn = 0;
          learningSamples = 0;
        }
      }
      else
      {
        learningDifference = 0;
        learningTurn = 0;
        learningSamples = 0;
      }
      const uint32_t bin = distance / BIN_COUNTS;
      if (bin >= MAP_CAPACITY) { fault = MAP_FULL; return NO_EVENT; }
      if (bin > binsUsed) { fault = MAP_GAP; return NO_EVENT; }
      if (curves[bin] == UNKNOWN_CURVE || abs(curves[bin]) < magnitude) { curves[bin] = bend; }
      binsUsed = static_cast<uint16_t>(bin + 1);
    }
    else
    {
      if (distance > learnedCounts + learnedCounts * 15 / 100)
      {
        fault = NO_FINISH;
        return NO_EVENT;
      }
      const uint16_t bin = static_cast<uint16_t>((distance % learnedCounts) / BIN_COUNTS);
      uint8_t expected = abs(curves[bin]);
      const uint16_t previous = bin ? bin - 1 : binsUsed - 1;
      const uint16_t next = bin + 1 < binsUsed ? bin + 1 : 0;
      if (abs(curves[previous]) > expected) { expected = abs(curves[previous]); }
      if (abs(curves[next]) > expected) { expected = abs(curves[next]); }
      if (magnitude > expected + 16)
      {
        mismatchMs += elapsedMs;
        if (mismatchMs >= 200) { fault = MAP_MISMATCH; return NO_EVENT; }
      }
      else { mismatchMs = 0; }
    }

    if (x * x + y * y > 150.0f * 150.0f) { leftStartZone = true; }
    if (leftStartZone && x < -50 && x > -300 && fabsf(y) < 150 && fabsf(heading) < 0.6f)
    {
      returnArmed = true;
    }
    // Cross the starting plane forwards, near the initial position and heading.
    const bool closure = returnArmed && previousX < 0 && x >= 0 &&
      fabsf(y) <= 80 && fabsf(heading) <= 0.25f;
    if (closure && distance * MM_PER_COUNT < 750)
    {
      fault = NO_FINISH; // Do not silently combine multiple small loops into one lap.
      return NO_EVENT;
    }
    if (!closure || (mapReady && distance < learnedCounts * 85 / 100)) { return NO_EVENT; }
    if (!mapReady)
    {
      learnedCounts = distance;
      mapReady = true;
    }
    lapTimes[completed] = now - lapStarted;
    completed++;
    if (completed == 2)
    { attackLap = mode == BEAST && !noisyLearning && cleanReplay && abs(turnVotes) >= 4; }
    if (completed == 3)
    {
      running = false;
      attackLap = false;
      return SESSION_FINISHED;
    }
    resetLap(now); // Anchor the next lap at the estimated crossing; do not accumulate pose error.
    return LAP_FINISHED;
  }

  // Share the live/map calculation to keep AVR flash use bounded.
  __attribute__((noinline)) uint32_t cornerSquared(uint8_t curvature, uint32_t lateralScale) const
  {
    const DriveProfile active = profile();
    if (curvature <= 3) { return static_cast<uint32_t>(active.cruise) * active.cruise; }
    const uint16_t geometry = trackWidthMm * curvature;
    int16_t wheelCap = static_cast<uint32_t>(active.limit - 8) * 12000 / (12000 + geometry);
    const int16_t turnCap = static_cast<uint32_t>(steeringLimit() - 12) * 12000 / geometry;
    if (wheelCap > turnCap) { wheelCap = turnCap; }
    if (wheelCap > active.cruise) { wheelCap = active.cruise; }
    const uint32_t wheelSquared = static_cast<uint32_t>(wheelCap) * wheelCap;
    uint32_t allowed = lateralScale * 6000 / curvature;
    if (allowed > wheelSquared) { allowed = wheelSquared; }
    return allowed < 4225 ? 4225 : allowed;
  }

  int16_t steeringFeedforward(int16_t base, int16_t error, uint8_t * yawWeight = nullptr) const
  {
    // Share map lookup: damping weight 0 disables it, 1 is half, 2 is full.
    if (yawWeight) { *yawWeight = 0; }
    if (!mapReady || !learnedCounts || abs(turnVotes) < 4) { return 0; }
    const uint16_t bin = (distanceCounts() % learnedCounts) / BIN_COUNTS;
    if (yawWeight)
    {
      // Weaken damping before a bend, including the lap's partial final bin.
      const uint16_t next = bin + 1 < binsUsed ? bin + 1 : 0;
      *yawWeight = abs(curves[bin]) <= 3 && abs(curves[next]) <= 3 && abs(filteredCurve) < 64 ? 2 : 1;
    }
    int8_t mapped = curves[bin];
    int16_t live = filteredCurve / 8;
    int16_t confidence = abs(live) * 8;
    if (confidence < abs(error)) { confidence = abs(error); }
    if (abs(live) < 8)
    {
      // Optical lookahead sees corner entry before the chassis starts rotating.
      if (noisyLearning || abs(error) < 60) { return 0; }
      live = (error > 0) == (turnVotes > 0) ? 8 : -8;
    }
    // A confirmed live bend may lead or trail the learned bin by a few cm.
    for (int8_t neighbor = -1; neighbor <= 1; neighbor++)
    {
      int16_t index = static_cast<int16_t>(bin) + neighbor;
      if (index < 0) { index = binsUsed - 1; }
      if (index >= static_cast<int16_t>(binsUsed)) { index = 0; }
      const int8_t candidate = curves[index];
      if (candidate != UNKNOWN_CURVE && static_cast<int16_t>(candidate) * live > 0 &&
        (mapped == UNKNOWN_CURVE || static_cast<int16_t>(mapped) * live <= 0 || abs(candidate) > abs(mapped)))
      { mapped = candidate; }
    }
    if (mapped == UNKNOWN_CURVE || static_cast<int16_t>(mapped) * live <= 0) { return 0; }
    int16_t bend = mapped;
    // Ramp the desired turn with measured entry confidence, without delaying
    // feedback or imposing a lagging slew limit on the wheel commands.
    if (noisyLearning) { bend = abs(mapped) < abs(live) ? mapped : live; }
    else if (confidence < 128) { bend = confidence <= 48 ? 0 : bend * (confidence - 48) / 80; }
    if (turnVotes < 0) { bend = -bend; }
    // Fade stale turn assistance continuously as the line asks to countersteer.
    // A binary veto caused assistance to switch on/off around corner exits.
    const int16_t opposing = bend > 0 ? -error : error;
    if (opposing >= 80) { return 0; }
    const int16_t assist = static_cast<int32_t>(base) * trackWidthMm * bend / 12000;
    return opposing > 0 ? static_cast<int32_t>(assist) * (80 - opposing) / 80 : assist;
  }

  int16_t plannedCruise() const
  {
    const DriveProfile active = profile();
    if (!mapReady || !learnedCounts || !binsUsed) { return active.cruise; }
    // v^2 = corner_v^2 + 2*a*distance. Plan for 250 PWM/s (200 when noisy),
    // below the output ramp's 300 PWM/s. Include 12.5% drivetrain uncertainty.
    const uint16_t scale = speedScaleQ8 + speedScaleQ8 / 8;
    const uint16_t brakeGain = (noisyLearning ? 28672U : 35840U) / scale;
    const uint16_t lateral = mode == BEAST ?
      (noisyLearning ? 2400 : (abs(turnVotes) < 4 ? 3600 : (attackLap ? 7000 : 5500))) :
      (mode == MID ? 2400 : 1200);
    const uint32_t lateralScale = (static_cast<uint32_t>(lateral) * 65536 / scale) / scale;
    const uint16_t guard = 125 + static_cast<uint16_t>(speedMmS * 0.04f / MM_PER_COUNT);
    uint32_t targetSquared = static_cast<uint32_t>(active.cruise) * active.cruise;
    const uint16_t window = static_cast<uint16_t>((targetSquared - 4225) / brakeGain) + guard;
    const uint32_t liveSquared = cornerSquared(abs(filteredCurve / 8), lateralScale);
    if (liveSquared < targetSquared) { targetSquared = liveSquared; }
    uint32_t point = distanceCounts() % learnedCounts;
    uint16_t offset = 0;
    while (offset <= window)
    {
      const uint16_t bin = static_cast<uint16_t>(point / BIN_COUNTS);
      const uint16_t clear = offset > guard ? offset - guard : 0;
      const uint32_t braking = static_cast<uint32_t>(clear) * brakeGain;
      // Even the minimum corner target cannot constrain speed beyond this point.
      if (4225 + braking >= targetSquared) { break; }
      const uint32_t allowed = (curves[bin] == UNKNOWN_CURVE ? 4225 :
        cornerSquared(abs(curves[bin]), lateralScale)) + braking;
      if (allowed < targetSquared) { targetSquared = allowed; }
      // The last map bin can be partial: visit bin zero immediately after wrap.
      const uint16_t nextBin = BIN_COUNTS - point % BIN_COUNTS;
      const uint32_t toStart = learnedCounts - point;
      const uint16_t step = toStart < nextBin ? static_cast<uint16_t>(toStart) : nextBin;
      offset += step;
      point += step;
      if (point == learnedCounts) { point = 0; }
    }
    // Integer floor square root; the motor ceiling bounds the result to 400.
    uint16_t root = 0;
    for (uint16_t bit = 256; bit; bit >>= 1)
    {
      const uint16_t candidate = root | bit;
      if (static_cast<uint32_t>(candidate) * candidate <= targetSquared) { root = candidate; }
    }
    return root;
  }
};
