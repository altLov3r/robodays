# Pololu 3pi+ Standard line follower

**R35 — finer map braking and cached drivetrain calculations, based on R34.**
For the stock **Pololu 3pi+ 32U4 OLED Standard, 30:1 MP motors**, black line on
a white floor. Two sketch files, no new Arduino libraries. The physically
successful R34 ZIP remains available for rollback and comparison.

## What changed

Reported R34 best laps: 2.89, 3.06, 2.98, 3.03, 2.89 seconds; A/L/S 24/4/0,
peak PWM 277 and dominant limiter M. That supports an incremental planner
change while preserving the successful steering and straight recovery.

- **Fractional braking calculation:** qualified Beast replay now retains eight
  fractional bits in its distance-to-speed coefficient. R34 truncated that
  coefficient to a whole number, adding a small rounding loss on approaches.
  The nominal rate remains 250 PWM/s with the same drivetrain margin. New
  targets stay within that original nominal envelope; the requested corner
  speed at the entry guard remains unchanged. One fixed fixture requests 393
  instead of 391 PWM on approach, then the same 303 PWM corner limit.
- **Cached fixed math:** lateral scale, braking coefficient, replay scan horizon
  and gyro-to-wheel conversion refresh when speed scale, effective width, mode,
  noisy fallback or geometry trust changes. Warm control ticks reuse them.
  Current speed, map position, live curvature and upcoming constraints still
  update every tick. A new session invalidates the cache. Its cost is 14 bytes
  of static RAM; actual AVR loop latency has not been measured.
- **Cleanup:** removed the obsolete running-bumper-stop configuration toggle.
  Running bumper stops remain disabled; startup/calibration checks remain.
  The compiler already removed the constant-false branch, so this source
  cleanup is not claimed as a separate speed gain.

R34's straight recovery gates, R24 steering gains, corner budget, motor
ceiling, 300 PWM/s routine output braking, entry guard and strict corner-exit
qualification are retained. Safe/Mid/noisy/untrusted-geometry paths keep their
previous braking arithmetic. The OLED stays blank during motion. Calibration,
three estimated laps, buttons, low-battery and other fault stops remain.

The focused checks verify cache invalidation across 900 mode/geometry/scale
combinations, warm/cold results, reset, and yaw access before map learning
finishes. Dense planning and nominal-braking-bound checks cover the new
rounding, both directions and multiple learned scales. Requested entry limits
and late-map guards retain their existing tests.

Eight paired motion cases completed with both frozen R34 and R35. Changes were
small and mixed: final modeled square laps changed 3510 to 3500 ms in one case,
3570 to 3560 in another, and 2960 to 2970 in the tighter case. Straights and the
70 ms command-recovery fixture were unchanged. These uncalibrated models do
not establish faster physical laps or improved consistency.

Compare R34/R35 sessions at similar battery charge and placement. Record both
racing laps and all attempted sessions, including failures. Consistent physical
sub-three-second laps remain a track-test goal, not a code-only guarantee.

## Install and upload

1. Extract `releases/PololuLineFollower-R35.zip`.
2. Open `PololuLineFollower/PololuLineFollower.ino` in Arduino IDE. Keep
   `RaceSession.h` beside it and replace **both files together**. Startup shows
   **R35**; mismatched planner revisions fail compilation.
3. Install **Pololu3piPlus32U4** through Library Manager and accept dependencies.
4. Select **Arduino Leonardo**, ATmega32U4 at 16 MHz, and the robot's USB port.
   The OLED edition is required; this is not firmware for Turtle/Hyper motors.
5. Upload, disconnect USB, and recalibrate. Development never flashes the robot
   automatically. Keep the previous release ZIP for rollback.

## Run

- **A:** automatic calibration. Allow the two-second hands-clear pause, then
  five slow, encoder-bounded turns with stopped pauses before reversal.
  Keep the robot on the line/white-floor boundary; do not turn it by hand.
- After calibration the OLED shows five sensor values and alignment arrows.
  Values run from 0 (white) to 1000 (black). Aim for `CENTERED` and the green
  LED, then point the robot along a straight. The screen cannot check heading.
- **C while stopped:** Safe → Mid → Beast → Safe. Power-on defaults to Safe.
- **B:** release to arm, then keep the robot still during the two-second gyro
  bias measurement. The first lap learns slowly; the next two use the map.
- The robot stops after **three estimated laps** and holds the results.
  Another B starts a fresh learning session. A reruns calibration.
- Any A/B/C button stops driving. During release-to-arm, the initiating A/B
  button may remain held. There is no blind lost-line recovery or auto restart.

Start from the same point and heading for comparisons. Use an open, flat test
area and first check a complete Safe session after upload. Then compare Beast
sessions on the same track and similar battery charge. Record completed/attempted
sessions, laps 2/3, scale/width, PWM, limiter and A/L/S shares.

Use four matching AAA NiMH cells with correct polarity and the stock covers on.
Charge the cells externally; USB does not charge them. No 10440 lithium cells.
The 4.40 V loaded cutoff is a stop threshold, not a target for timed comparisons.

## Modes and planning

All values are **PWM commands out of 400**, not measured speeds.

| Stage | Straight target | Wheel ceiling |
| --- | ---: | ---: |
| Learning, every mode | 80 | 100 |
| Safe replay | 120 | 140 |
| Mid replay | 180 | 220 |
| Beast replay | 400 | 400 |

Sustained noisy Beast learning selects a Mid fallback for both replay laps.
One isolated derivative spike cannot latch it, and a replay error cannot change
the session's motor ceiling. Errors during replay still reduce speed locally.

The 512-byte signed-curvature map has bins of 128 encoder counts, about 36 mm
with stock wheels, and covers about 18.4 m. Turning is integrated by distance
and split at bin boundaries; opposite steering wiggles can cancel within a bin.
Every new session discards the previous map. Learning also estimates speed/PWM
scale and gyro polarity/effective wheel spacing.

Planning combines mapped corner lookahead, live gyro curvature, optical error
and filtered error derivative. The nominal lateral budgets are 1200/2400/6000 mm/s² for
Safe/Mid/qualified Beast, with a 12.5% drivetrain margin. Beast uses a lower
budget without trusted geometry. These are tuning assumptions, not measured
friction limits. Both replay laps use the same budget. Wheel ceilings and
differential steering room also constrain speed. No reverse wheel commands are used during line following.

Planned braking is 250 PWM/s, or 200 for noisy-learning fallback.
The common output ramp brakes at 300 PWM/s. Large line errors/crossings retain
an urgent slowdown; faults stop immediately. Steering allocation can also reduce
wheel-average output immediately. The code therefore does not promise a limit
on every physical deceleration or eliminate pitching. Running bumper stops
remain disabled as requested; startup/calibration bumper checks remain active.

**Finish detection has no physical marker.** Encoder/gyro pose estimates can
drift with slip or repeated geometry. This code stops after three detected
returns; it cannot guarantee exactly three physical laps or exact finish timing.
Use a distinct finish reference if exact counting is required. Small loops,
branches, crossings and nearby parallel sections need separate track validation.

## Read the results

| Display | Meaning |
| --- | --- |
| `820/84` | Learned speed-scale Q8 / effective wheel width in mm. Divide 820 by 256 for model mm/s per PWM. |
| `A/L/S 33/22/16` | Integer replay tick percentages for acceleration / optical line cap / steering allocation. |
| `LAP 1/2/3` | Estimated lap times; lap 1 is learning. |
| `PWM 280/290` | Peak actual wheel-average command / peak common throttle before steering trim. Independent maxima. |
| `LIMIT: M/Y/L/A/S/F` | Most frequent replay limiter: map / live yaw / optical line / acceleration / steering / satisfied cruise target. |
| `LIMIT: G` | Insufficient learned gyro geometry/polarity confidence. |
| `MID FALLBACK` | Sustained noisy learning selected the fallback. |

Tick-count ties choose M, L, A, S, F, then Y. A dominant `A` does not establish
how much time more acceleration could save. Shares use floor-rounded percentages
and need not total 100 because other limiter categories also exist.

A run stopped early holds its reason and last valid `error/filteredDerivative`
pair. After `NO LINE`, that pair is the preceding valid sample, not a measured
off-track position. The screen stays until A/B/C.

| Stop | Check |
| --- | --- |
| `BAD CAL`, `CENTRE!`, `NO LINE` | Calibration, line/white contrast, placement and sensor height. |
| `BAT LOW/HIGH` | Cell charge/type, polarity and contacts. |
| `STALLED`, `ENC DIR/ERR` | Free wheels, assembly, encoders and power. |
| `DARK/AIR` | Wide crossing, floor/sensor geometry or loss of contrast. |
| `LOOP LAG`, `IMU ERROR`, `GYRO STALE/RANGE` | Timing, IMU/I2C and unexpected motion. |
| `HOLD STILL`, `GYRO CAL` | Remain still throughout the start countdown. |
| `MAP FULL/GAP/MISMATCH`, `NO FINISH` | Map capacity, grip, loop geometry and return estimate. |
| `MOTION ERROR` | Motion outside encoder/gyro estimator bounds. |
| `USB OUT`, `STOPPED`, `TIME END` | Disconnect USB, deliberate cancellation or session timeout. |

Do not bypass a stop to force a finish. A nose strike or departure still needs
physical inspection/tuning; compilation cannot establish track stability.

## Validation

Run the focused checks with:

```powershell
python tests/run_tests.py --focused
```

They compile the actual sketch against fake hardware and check calibration,
startup/UI/buttons, mode ceilings, battery/USB/IMU/encoder/stall faults, watchdog
upload handoff, fractional ramps, timing rollover, predictive line limits, yaw
feedback, corner holds, output bounds, diagnostics and the three-lap stop latch.

R35 adds cold/warm drive-model cache checks, mode/geometry/scale invalidation,
reset and learning-to-replay horizon checks. New dense-distance comparisons
verify fractional braking, preserve the prior requested corner limits and
bound approach requests by the existing nominal deceleration. Existing R34
straight-recovery, calibration, UI, motor limits, map, timing and stop checks
remain enabled. Tests keep the late-entry cases with three bins of map delay
and 20 ms lead, or two bins and 40 ms lead. Those are software requests, not
measured physical stopping margins.

Run the limited paired motion comparison separately:

```powershell
python tests/compare_motion.py --baseline R34 --output releases/PololuLineFollower-R35-motion.json
```

This compiles the same test harness against frozen R34 and current firmware.
The models use 10 ms motion steps; the command-recovery fixture uses 5 ms.
Comparison mode records outcomes without enforcing old historical timing or
soft-brake expectations. The focused suite retains its fault/limit checks.
The full historical trajectory suite was not run. The R35 ZIP includes all
comparison data in `MOTION_COMPARISON.json`.

The actual OLED/Leonardo build passes with warnings enabled:
**28,002/28,672 bytes flash; 1,505/2,560 bytes static RAM**. This leaves 670 bytes
of flash and 1,055 bytes for stack/local allocation, not a measured free-stack
minimum. The linked ELF contains no malloc/realloc/free allocator symbols.

Validation toolchain: Arduino AVR Boards 1.8.8, Pololu3piPlus32U4 1.1.3,
PololuOLED 2.0.0, FastGPIO 2.2.0, Pushbutton 2.0.0 and USBPause 2.0.0.
Different compiler/library versions can change resource usage. No library files
were modified. The compact Pololu-derived font and its MIT notice are embedded
in the sketch; emitted text renders in uppercase.

No hardware upload or physical R35 test was performed during development.
Firmware PWM bounds do not establish physical motor/gearbox protection or
collision prevention. Verify on your track before relying on competition runs.

## References

- [Pololu 3pi+ user guide](https://www.pololu.com/docs/0J83/all)
- [Official Arduino library](https://github.com/pololu/pololu-3pi-plus-32u4-arduino-library)
- [OLED library](https://github.com/pololu/pololu-oled-arduino)
